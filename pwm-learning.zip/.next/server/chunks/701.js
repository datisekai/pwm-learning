"use strict";
exports.id = 701;
exports.ids = [701];
exports.modules = {

/***/ 2701:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_axiosClient__WEBPACK_IMPORTED_MODULE_0__]);
_config_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const SpeciesAction = {
    getAll: async (status = 0)=>{
        try {
            const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/species?status=${status}`);
            return result.data;
        } catch (error) {
            console.log(error);
            return [];
        }
    },
    add: async (data)=>{
        const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/species", data);
        return result.data;
    },
    update: async (data)=>{
        const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].put */ .Z.put(`/species/${data.id}`, data);
        return result.data;
    },
    delete: async (id)=>{
        const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/species/${id}`);
        return result.data;
    },
    home: async ()=>{
        try {
            const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/species/user?limit=8");
            return result.data;
        } catch (error) {
            return [];
        }
    },
    setMenu: async (id)=>{
        try {
            const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].put */ .Z.put(`/species/menu/${id}`);
            return result.data;
        } catch (error) {
            return null;
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SpeciesAction);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;