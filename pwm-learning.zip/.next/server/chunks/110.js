"use strict";
exports.id = 110;
exports.ids = [110];
exports.modules = {

/***/ 9110:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_axiosClient__WEBPACK_IMPORTED_MODULE_0__]);
_config_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const CategoryBlogAction = {
    getAll: async ()=>{
        try {
            const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/category-blog");
            return result.data;
        } catch (error) {
            console.log(error);
            return [];
        }
    },
    add: async (name)=>{
        const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/category-blog", {
            name
        });
        return result.data;
    },
    update: async (data)=>{
        const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].put */ .Z.put(`/category-blog/${data.id}`, {
            ...data
        });
        return result.data;
    },
    delete: async (id)=>{
        const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/category-blog/${id}`);
        return result.data;
    },
    getBySlug: async (data)=>{
        try {
            const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/category-blog/search?slug=${data.slug}&page=${data.page || 1}&limit=${data.limit}`);
            return result.data;
        } catch (error) {
            console.log(error);
            return null;
        }
    },
    getByUser: async ()=>{
        const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/category-blog/user");
        return result.data;
    },
    setMenu: async (id)=>{
        try {
            const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].put */ .Z.put(`/category-blog/menu/${id}`);
            return result.data;
        } catch (error) {
            return null;
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoryBlogAction);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;