"use strict";
exports.id = 361;
exports.ids = [361];
exports.modules = {

/***/ 9361:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "El": () => (/* binding */ generateAvatar),
/* harmony export */   "KT": () => (/* binding */ getImageServer),
/* harmony export */   "Ti": () => (/* binding */ uploadImg),
/* harmony export */   "b3": () => (/* binding */ validURL),
/* harmony export */   "eQ": () => (/* binding */ formatPrices),
/* harmony export */   "uf": () => (/* binding */ formatNumber)
/* harmony export */ });
/* harmony import */ var _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_axiosClient__WEBPACK_IMPORTED_MODULE_0__]);
_config_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const formatPrices = (price)=>{
    return new Intl.NumberFormat("vi-VI", {
        style: "currency",
        currency: "VND"
    }).format(price);
};
const generateAvatar = (email)=>{
    return `https://ui-avatars.com/api/?background=EA8143&color=fff&name=${email}`;
};
const formatNumber = (value)=>{
    return value.toLocaleString("en-IN", {
        maximumSignificantDigits: 3
    });
};
const getImageServer = (filename)=>{
    return `${"https://api.pwm.edu.vn"}/images/${filename}`;
};
const uploadImg = async (files)=>{
    const formData = new FormData();
    formData.append("pwm-file", files);
    try {
        const res = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/upload/image", formData);
        return res.data.url;
    } catch (error) {
        console.log(error);
    }
};
function validURL(str) {
    var pattern = new RegExp("^(https?:\\/\\/)?" + // protocol
    "((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|" + // domain name
    "((\\d{1,3}\\.){3}\\d{1,3}))" + // OR ip (v4) address
    "(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*" + // port and path
    "(\\?[;&a-z\\d%_.~+=-]*)?" + // query string
    "(\\#[-a-z\\d_]*)?$", "i"); // fragment locator
    return !!pattern.test(str);
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;