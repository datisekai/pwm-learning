"use strict";
(() => {
var exports = {};
exports.id = 518;
exports.ids = [518];
exports.modules = {

/***/ 9106:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9752);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6201);
/* harmony import */ var _actions_User_action__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7231);
/* harmony import */ var _customs_Select__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1426);
/* harmony import */ var _customs_TextField__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6220);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_User_action__WEBPACK_IMPORTED_MODULE_6__, _customs_Select__WEBPACK_IMPORTED_MODULE_7__, _customs_TextField__WEBPACK_IMPORTED_MODULE_8__]);
([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_User_action__WEBPACK_IMPORTED_MODULE_6__, _customs_Select__WEBPACK_IMPORTED_MODULE_7__, _customs_TextField__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const ModalAddUser = ({ handleClose , open , data  })=>{
    const { control , formState: { errors  } , handleSubmit , getValues , watch , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        defaultValues: {
            email: "",
            password: "",
            permissionId: ""
        }
    });
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const queryClient = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQueryClient)();
    const { mutate , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(_actions_User_action__WEBPACK_IMPORTED_MODULE_6__/* ["default"].add */ .Z.add, {
        onSuccess: (data)=>{
            const dataUserOld = queryClient.getQueryData([
                "users"
            ]) || [];
            queryClient.setQueryData([
                "users"
            ], [
                data,
                ...dataUserOld
            ]);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success("Th\xeam th\xe0nh c\xf4ng");
            handleClose();
            reset();
        },
        onError: (err)=>{
            console.log(err);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("C\xf3 lỗi xảy ra, vui l\xf2ng thử lại");
        }
    });
    const handleUpdate = (data)=>{
        mutate(data);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${!open && "hidden"} `,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "fixed inset-0 bg-[rgba(0,0,0,0.6)] z-[60]",
                onClick: handleClose
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-[90%] md:w-[500px] p-4 rounded-lg bg-white fixed z-[70] top-[50%] translate-y-[-50%] translate-x-[-50%] left-[50%] ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold",
                        children: "Th\xeam người d\xf9ng"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-4 space-y-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "Email"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_TextField__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                        control: control,
                                        error: errors,
                                        name: "email",
                                        className: "css-field",
                                        placeholder: "Nhập v\xe0o",
                                        rules: {
                                            required: "Vui l\xf2ng kh\xf4ng bỏ trống",
                                            pattern: {
                                                value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                                                message: "Định dạng email chưa đ\xfang"
                                            }
                                        }
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "Mật khẩu"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_TextField__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                        control: control,
                                        error: errors,
                                        name: "password",
                                        className: "css-field",
                                        placeholder: "Nhập v\xe0o",
                                        rules: {
                                            required: "Vui l\xf2ng kh\xf4ng bỏ trống"
                                        }
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "Loại quyền"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_Select__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        control: control,
                                        data: data?.map((item)=>({
                                                text: item.name,
                                                value: item.id
                                            })),
                                        rules: {
                                            required: "Kh\xf4ng được để trống \xf4"
                                        },
                                        error: errors,
                                        name: "permissionId",
                                        className: "css-field"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-4 flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                disabled: isLoading,
                                onClick: handleClose,
                                type: "button",
                                className: "text-gray-500 bg-gray-100 hover:bg-gray-300 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600",
                                children: "Đ\xf3ng"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                disabled: isLoading,
                                onClick: handleSubmit(handleUpdate),
                                className: "text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800",
                                children: "Lưu"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModalAddUser);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7514:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9752);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6201);
/* harmony import */ var _actions_User_action__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7231);
/* harmony import */ var _customs_Select__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1426);
/* harmony import */ var _customs_TextField__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6220);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_User_action__WEBPACK_IMPORTED_MODULE_6__, _customs_Select__WEBPACK_IMPORTED_MODULE_7__, _customs_TextField__WEBPACK_IMPORTED_MODULE_8__]);
([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_User_action__WEBPACK_IMPORTED_MODULE_6__, _customs_Select__WEBPACK_IMPORTED_MODULE_7__, _customs_TextField__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const ModalUpdateUser = ({ handleClose , open , data , current  })=>{
    const { control , formState: { errors  } , handleSubmit , getValues , watch , setValue  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        defaultValues: {
            email: "",
            permissionId: "",
            password: ""
        }
    });
    const queryClient = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQueryClient)();
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setValue("email", current?.email);
        setValue("permissionId", current?.permissionId.toString());
    }, [
        current
    ]);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { mutate , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(_actions_User_action__WEBPACK_IMPORTED_MODULE_6__/* ["default"].update */ .Z.update, {
        onSuccess: (data, variables)=>{
            const dataUserOld = queryClient.getQueryData([
                "users"
            ]) || [];
            queryClient.setQueryData([
                "users"
            ], dataUserOld.map((item)=>{
                if (item.id == data.id) {
                    return data;
                }
                return item;
            }));
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success("Cập nhật th\xe0nh c\xf4ng");
            handleClose();
        },
        onError: (err)=>{
            console.log(err);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("C\xf3 lỗi xảy ra, vui l\xf2ng thử lại");
        }
    });
    const handleUpdate = (data)=>{
        mutate({
            ...data,
            id: current?.id,
            password: data.password ? data.password : undefined
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${!open && "hidden"} `,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "fixed inset-0 bg-[rgba(0,0,0,0.6)] z-[60]",
                onClick: handleClose
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-[90%] md:w-[500px] p-4 rounded-lg bg-white fixed z-[70] top-[50%] translate-y-[-50%] translate-x-[-50%] left-[50%] ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold",
                        children: "Cập nhật người d\xf9ng"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-4 space-y-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "Email"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_TextField__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                        control: control,
                                        error: errors,
                                        name: "email",
                                        className: "css-field",
                                        placeholder: "Nhập v\xe0o",
                                        rules: {
                                            required: "Vui l\xf2ng kh\xf4ng bỏ trống",
                                            pattern: {
                                                value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                                                message: "Định dạng email chưa đ\xfang"
                                            }
                                        }
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "Mật khẩu"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_TextField__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                        control: control,
                                        error: errors,
                                        name: "password",
                                        className: "css-field",
                                        placeholder: "Nhập v\xe0o"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "Loại quyền"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_Select__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        control: control,
                                        data: data?.map((item)=>({
                                                text: item.name,
                                                value: item.id
                                            })),
                                        rules: {
                                            required: "Kh\xf4ng được để trống \xf4"
                                        },
                                        error: errors,
                                        name: "permissionId",
                                        className: "css-field"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-4 flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                disabled: isLoading,
                                onClick: handleClose,
                                type: "button",
                                className: "text-gray-500 bg-gray-100 hover:bg-gray-300 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600",
                                children: "Đ\xf3ng"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                disabled: isLoading,
                                onClick: handleSubmit(handleUpdate),
                                className: "text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800",
                                children: "Lưu"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModalUpdateUser);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5841:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9752);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6201);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8625);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_ci__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var sweetalert__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4701);
/* harmony import */ var sweetalert__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(sweetalert__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _actions_Permission_action__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9097);
/* harmony import */ var _actions_User_action__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7231);
/* harmony import */ var _components_admin_users_ModalAddUser__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9106);
/* harmony import */ var _components_admin_users_ModalUpdateUser__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7514);
/* harmony import */ var _components_context__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(506);
/* harmony import */ var _components_layouts_AdminLayout__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9408);
/* harmony import */ var _components_LoadingSpinner__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3595);
/* harmony import */ var _components_Meta__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4154);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_Permission_action__WEBPACK_IMPORTED_MODULE_9__, _actions_User_action__WEBPACK_IMPORTED_MODULE_10__, _components_admin_users_ModalAddUser__WEBPACK_IMPORTED_MODULE_11__, _components_admin_users_ModalUpdateUser__WEBPACK_IMPORTED_MODULE_12__, _components_context__WEBPACK_IMPORTED_MODULE_13__, _components_layouts_AdminLayout__WEBPACK_IMPORTED_MODULE_14__]);
([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_Permission_action__WEBPACK_IMPORTED_MODULE_9__, _actions_User_action__WEBPACK_IMPORTED_MODULE_10__, _components_admin_users_ModalAddUser__WEBPACK_IMPORTED_MODULE_11__, _components_admin_users_ModalUpdateUser__WEBPACK_IMPORTED_MODULE_12__, _components_context__WEBPACK_IMPORTED_MODULE_13__, _components_layouts_AdminLayout__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const UserAdmin = ()=>{
    const [openModalAdd, setOpenModalAdd] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [openModalUpdate, setOpenModalUpdate] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_components_context__WEBPACK_IMPORTED_MODULE_13__/* .AuthContext */ .V);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const { page =1  } = router.query;
    const { data: permissions , isLoading: isLoadingPermission  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)([
        "permissions"
    ], _actions_Permission_action__WEBPACK_IMPORTED_MODULE_9__/* ["default"].getAll */ .Z.getAll);
    const { data: users , isLoading: isLoadingUser  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)([
        "users"
    ], _actions_User_action__WEBPACK_IMPORTED_MODULE_10__/* ["default"].getAll */ .Z.getAll);
    const queryClient = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQueryClient)();
    const { mutate , isLoading: isLoadingDelete  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(_actions_User_action__WEBPACK_IMPORTED_MODULE_10__/* ["default"]["delete"] */ .Z["delete"], {
        onSuccess: (data, variables)=>{
            queryClient.setQueryData([
                "users"
            ], users?.filter((item)=>item.id != variables));
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success("Đ\xe3 chuyển v\xe0o th\xf9ng r\xe1c");
            router.replace(router.asPath);
        },
        onError: (err)=>{
            console.log(err);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("C\xf3 lỗi xảy ra, vui l\xf2ng thử lại");
        }
    });
    const handleDelete = (id)=>{
        sweetalert__WEBPACK_IMPORTED_MODULE_8___default()({
            title: "Bạn c\xf3 chắc chắn muốn x\xf3a?",
            text: "Khi x\xf3a, đối tượng sẽ được chuyển v\xe0o th\xf9ng r\xe1c",
            icon: "warning",
            buttons: [
                "Hủy",
                "X\xf3a"
            ],
            dangerMode: true
        }).then((willDelete)=>{
            if (willDelete) {
                mutate(id);
            }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Meta__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                image: "/images/logo.jpg",
                title: "Người d\xf9ng | Admin",
                description: ""
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_AdminLayout__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mt-5 grid",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                            className: "text-white bg-primary px-4 py-2 inline rounded-lg",
                                            children: "Quản l\xfd người d\xf9ng"
                                        }),
                                        user?.detailActions.includes("user:add") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            onClick: ()=>setOpenModalAdd(true),
                                            className: "px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-700",
                                            children: "Th\xeam người d\xf9ng"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "mt-4 bg-white rounded-3xl p-4 max-h-[450px] overflow-x-auto shadow-master",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "relative",
                                        children: !isLoadingUser || !isLoadingPermission ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                            className: "table-auto w-full text-sm text-left text-gray-500 dark:text-gray-400",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                    className: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                scope: "col",
                                                                className: "py-2 px-3 md:py-3 md:px-6",
                                                                children: "Email"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                scope: "col",
                                                                className: "py-2 px-3 md:py-3 md:px-6",
                                                                children: "Loại quyền"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                scope: "col",
                                                                className: "py-2 px-3 md:py-3 md:px-6",
                                                                children: "Ng\xe0y tạo"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                scope: "col",
                                                                className: "py-2 px-3 md:py-3 md:px-6",
                                                                children: "Ng\xe0y cập nhật"
                                                            }),
                                                            (user?.detailActions.includes("user:update") || user?.detailActions.includes("user:delete")) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                scope: "col",
                                                                className: "py-2 px-3 md:py-3 md:px-6",
                                                                children: "H\xe0nh động"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                    children: users?.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                            className: "bg-white border-b dark:bg-gray-800 dark:border-gray-700",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                    scope: "row",
                                                                    className: "break-words max-w-[200px] px-2 py-3 md:py-4 md:px-6 font-medium text-gray-900 line-clamp-1 dark:text-white",
                                                                    children: item.email
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                    className: "px-2 py-3 md:py-4 md:px-6 break-words max-w-[200px]",
                                                                    children: item.permission.name
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                    className: "px-2 py-3 md:py-4 md:px-6",
                                                                    children: dayjs__WEBPACK_IMPORTED_MODULE_2___default()(item.createdAt).format("DD/MM/YYYY")
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                    className: "px-2 py-3 md:py-4 md:px-6",
                                                                    children: dayjs__WEBPACK_IMPORTED_MODULE_2___default()(item.updatedAt).format("DD/MM/YYYY")
                                                                }),
                                                                (user?.detailActions.includes("user:update") || user?.detailActions.includes("user:delete")) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                    className: "px-2 py-3 md:py-4 md:px-6",
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "flex",
                                                                        children: [
                                                                            user?.detailActions.includes("user:update") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                onClick: ()=>{
                                                                                    setCurrent(item);
                                                                                    setOpenModalUpdate(true);
                                                                                },
                                                                                className: "bg-primary flex items-center justify-center text-white p-1 rounded-md hover:bg-primaryHover cursor-pointer",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ci__WEBPACK_IMPORTED_MODULE_6__.CiEdit, {
                                                                                    fontSize: 24
                                                                                })
                                                                            }),
                                                                            user?.detailActions.includes("user:delete") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                onClick: ()=>handleDelete(item.id),
                                                                                className: "ml-2 bg-red-500 flex items-center justify-center text-white p-1 rounded-md hover:bg-red-700 cursor-pointer",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_7__.RiDeleteBin6Line, {
                                                                                    fontSize: 24
                                                                                })
                                                                            })
                                                                        ]
                                                                    })
                                                                })
                                                            ]
                                                        }, item.id))
                                                })
                                            ]
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex items-center justify-center",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_LoadingSpinner__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                                isFullScreen: false
                                            })
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_admin_users_ModalAddUser__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            data: permissions || [],
                            handleClose: ()=>setOpenModalAdd(false),
                            open: openModalAdd
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_admin_users_ModalUpdateUser__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            current: current,
                            data: permissions || [],
                            handleClose: ()=>setOpenModalUpdate(false),
                            open: openModalUpdate
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserAdmin);
const getServerSideProps = async ({ req  })=>{
    const detailActions = JSON.parse(req.cookies["detailActions"] || "[]");
    if (!detailActions.includes("user:view")) {
        return {
            props: {},
            redirect: {
                destination: "/admin"
            }
        };
    }
    return {
        props: {}
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8982:
/***/ ((module) => {

module.exports = require("cookies-next");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 7840:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 8625:
/***/ ((module) => {

module.exports = require("react-icons/ci");

/***/ }),

/***/ 8098:
/***/ ((module) => {

module.exports = require("react-icons/ri");

/***/ }),

/***/ 4152:
/***/ ((module) => {

module.exports = require("react-icons/tb");

/***/ }),

/***/ 1740:
/***/ ((module) => {

module.exports = require("react-icons/tfi");

/***/ }),

/***/ 382:
/***/ ((module) => {

module.exports = require("react-icons/vsc");

/***/ }),

/***/ 9252:
/***/ ((module) => {

module.exports = require("react-lazy-load-image-component");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4701:
/***/ ((module) => {

module.exports = require("sweetalert");

/***/ }),

/***/ 9752:
/***/ ((module) => {

module.exports = import("@tanstack/react-query");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 6201:
/***/ ((module) => {

module.exports = import("react-hot-toast");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,676,664,183,154,506,361,231,408,220,595,426,97], () => (__webpack_exec__(5841)));
module.exports = __webpack_exports__;

})();