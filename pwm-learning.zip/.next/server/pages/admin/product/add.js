"use strict";
(() => {
var exports = {};
exports.id = 617;
exports.ids = [617];
exports.modules = {

/***/ 3113:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_axiosClient__WEBPACK_IMPORTED_MODULE_0__]);
_config_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const CategoryAction = {
    getAll: async ()=>{
        try {
            const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/category");
            return result.data;
        } catch (error) {
            console.log(error);
            return [];
        }
    },
    add: async (data)=>{
        const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/category", data);
        return result.data;
    },
    update: async (data)=>{
        const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].put */ .Z.put(`/category/${data.id}`, data);
        return result.data;
    },
    delete: async (id)=>{
        const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/category/${id}`);
        return result.data;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoryAction);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1480:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_fc__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(178);
/* harmony import */ var react_icons_fc__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_fc__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9252);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_3__);




const TableProductAdmin = ({ classify1 , classify2 , groupClassify , dataTable , handleChange , skus  })=>{
    const classify = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        const data = [];
        const newClassify1 = classify1.filter((item)=>item.text != "");
        const newClassify2 = classify2.filter((item)=>item.text != "");
        newClassify1.forEach((item)=>{
            if (newClassify2.length > 0) {
                newClassify2.forEach((element)=>{
                    data.push(element);
                });
            } else {
                data.push(item);
            }
        });
        return data;
    }, [
        classify1,
        classify2,
        groupClassify
    ]);
    const col = [
        {
            name: groupClassify[0].text != "" ? groupClassify[0].text : "Nh\xf3m PL 1"
        },
        {
            name: groupClassify.length === 2 && groupClassify[1].text != "" ? groupClassify[1].text : "Nh\xf3m PL 2",
            hidden: groupClassify.length !== 2
        },
        {
            name: "Gi\xe1"
        },
        {
            name: "SKU ph\xe2n loại"
        },
        {
            name: "% giảm"
        }
    ];
    const handleChangeData = (position, key, value)=>{
        const data = skus.map((item, index)=>{
            if (index === position) {
                if (key === "file") {
                    return {
                        ...item,
                        [key]: value,
                        preview: URL.createObjectURL(value)
                    };
                } else {
                    return {
                        ...item,
                        [key]: value
                    };
                }
            }
            return item;
        });
        handleChange(data);
    };
    const handleChangeAllSku = (key, value)=>{
        handleChange(skus.map((item)=>{
            return {
                ...item,
                [key]: value
            };
        }));
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "grid grid-cols-3 gap-2 mb-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        type: "text",
                        onChange: (e)=>handleChangeAllSku("price", e.target.value),
                        className: "border outline-none text-sm px-2 py-1 rounded-md",
                        placeholder: "Gi\xe1"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        type: "text",
                        onChange: (e)=>handleChangeAllSku("skuPhanLoai", e.target.value),
                        className: "border outline-none text-sm px-2 py-1 rounded-md",
                        placeholder: "SKU ph\xe2n loại"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        type: "text",
                        onChange: (e)=>handleChangeAllSku("discount", e.target.value),
                        className: "border outline-none text-sm px-2 py-1 rounded-md",
                        placeholder: "% giảm"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "overflow-x-auto relative",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                    className: "w-full text-sm text-left text-gray-500 dark:text-gray-400",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                            className: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                children: col.map((item, index)=>!item.hidden && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                        scope: "col",
                                        className: "py-3 px-1",
                                        children: item.name
                                    }, index))
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                            children: dataTable?.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                    className: "bg-white border-b dark:bg-gray-800 dark:border-gray-700",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            scope: "row",
                                            className: "py-4 px-1 font-medium text-gray-900 whitespace-nowrap dark:text-white",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: item[0].text
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "file",
                                                                className: "hidden",
                                                                accept: "image/*",
                                                                onChange: (e)=>handleChangeData(index, "file", e.target.files ? e.target.files[0] : null),
                                                                id: `fileImage-${index}`
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: `fileImage-${index}`,
                                                                className: "cursor-pointer ",
                                                                children: skus[index].preview == "" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fc__WEBPACK_IMPORTED_MODULE_2__.FcAddImage, {
                                                                    fontSize: 40
                                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_3__.LazyLoadImage, {
                                                                    src: skus[index].preview,
                                                                    className: "w-[40px] h-[40px]"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        }),
                                        groupClassify.length === 2 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            className: "py-4 px-1",
                                            children: item.length === 2 && item[1].text
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            className: "py-4 px-1",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "text",
                                                value: skus[index].price || "",
                                                onChange: (e)=>handleChangeData(index, "price", e.target.value),
                                                className: "w-full outline-none border rounded-md px-2 py-1",
                                                placeholder: "Nhập v\xe0o"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            className: "py-4 px-1",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                value: skus[index].skuPhanLoai || "",
                                                onChange: (e)=>handleChangeData(index, "skuPhanLoai", e.target.value),
                                                type: "text",
                                                className: "w-full outline-none border rounded-md px-2 py-1",
                                                placeholder: "Nhập v\xe0o"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            className: "py-4 px-1",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                value: skus[index].discount || "",
                                                onChange: (e)=>handleChangeData(index, "discount", e.target.value),
                                                type: "text",
                                                className: "w-full outline-none border rounded-md px-2 py-1",
                                                placeholder: "Nhập v\xe0o"
                                            })
                                        })
                                    ]
                                }, `${item.id}${index}`))
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TableProductAdmin);


/***/ }),

/***/ 4525:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_layouts_AdminLayout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9408);
/* harmony import */ var react_icons_fc__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(178);
/* harmony import */ var react_icons_fc__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_fc__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_customs_TextField__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6220);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5641);
/* harmony import */ var _components_customs_Select__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1426);
/* harmony import */ var _components_customs_TextArea__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2216);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8547);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_gr__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6555);
/* harmony import */ var _components_admin_products_TableProductAdmin__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1480);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9252);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _actions_Category_action__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3113);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9361);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6201);
/* harmony import */ var _actions_Product_action__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(5183);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(9752);
/* harmony import */ var _components_Meta__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(4154);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layouts_AdminLayout__WEBPACK_IMPORTED_MODULE_2__, _components_customs_TextField__WEBPACK_IMPORTED_MODULE_4__, react_hook_form__WEBPACK_IMPORTED_MODULE_5__, _components_customs_Select__WEBPACK_IMPORTED_MODULE_6__, _components_customs_TextArea__WEBPACK_IMPORTED_MODULE_7__, uuid__WEBPACK_IMPORTED_MODULE_10__, _actions_Category_action__WEBPACK_IMPORTED_MODULE_13__, _utils__WEBPACK_IMPORTED_MODULE_14__, react_hot_toast__WEBPACK_IMPORTED_MODULE_15__, _actions_Product_action__WEBPACK_IMPORTED_MODULE_16__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_18__]);
([_components_layouts_AdminLayout__WEBPACK_IMPORTED_MODULE_2__, _components_customs_TextField__WEBPACK_IMPORTED_MODULE_4__, react_hook_form__WEBPACK_IMPORTED_MODULE_5__, _components_customs_Select__WEBPACK_IMPORTED_MODULE_6__, _components_customs_TextArea__WEBPACK_IMPORTED_MODULE_7__, uuid__WEBPACK_IMPORTED_MODULE_10__, _actions_Category_action__WEBPACK_IMPORTED_MODULE_13__, _utils__WEBPACK_IMPORTED_MODULE_14__, react_hot_toast__WEBPACK_IMPORTED_MODULE_15__, _actions_Product_action__WEBPACK_IMPORTED_MODULE_16__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_18__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




















const AddProduct = ({ categories  })=>{
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{}, []);
    const { control , formState: { errors  } , handleSubmit , getValues , watch  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_5__.useForm)({
        defaultValues: {
            name: "",
            category: "",
            description: ""
        }
    });
    const [groupClassify, setGroupClassify] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        {
            id: (0,uuid__WEBPACK_IMPORTED_MODULE_10__.v4)(),
            text: ""
        }
    ]);
    const [classify1, setClassify1] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        {
            id: (0,uuid__WEBPACK_IMPORTED_MODULE_10__.v4)(),
            text: "",
            attributeId: groupClassify[0].id
        }
    ]);
    const [classify2, setClassify2] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        {
            id: (0,uuid__WEBPACK_IMPORTED_MODULE_10__.v4)(),
            text: "",
            attributeId: groupClassify.length > 1 && groupClassify[1].id
        }
    ]);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_17__.useRouter)();
    const [thumbnail, setThumbnail] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [preview, setPreview] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [skus, setSkus] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const maxLength = 120;
    const name = watch("name");
    const { mutate , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_18__.useMutation)(_actions_Product_action__WEBPACK_IMPORTED_MODULE_16__/* ["default"].add */ .Z.add, {
        onSuccess: ()=>{
            react_hot_toast__WEBPACK_IMPORTED_MODULE_15__.toast.success("Th\xeam th\xe0nh c\xf4ng");
            router.push("/admin/product");
        },
        onError: ()=>{
            react_hot_toast__WEBPACK_IMPORTED_MODULE_15__.toast.error("C\xf3 lỗi xảy ra, vui l\xf2ng thử lại");
        }
    });
    const handleAdd = async (data)=>{
        const newProduct = {
            categoryId: data.category,
            name: data.name,
            description: data.description,
            thumbnail: "",
            attributes: groupClassify.filter((item)=>item.text != "").map((item)=>({
                    ...item,
                    name: item.text,
                    text: undefined
                })),
            skuValue: []
        };
        if (!thumbnail) {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_15__.toast.error("Vui l\xf2ng chọn ảnh ch\xednh");
            return;
        }
        if (newProduct.attributes.length === 0) {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_15__.toast.error("Vui l\xf2ng nhập nh\xf3m ph\xe2n loại");
            return;
        }
        if (classify1.filter((item)=>item.text != "").length === 0) {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_15__.toast.error("Vui l\xf2ng nhập chi tiết ph\xe2n loại 1");
            return;
        }
        if (newProduct.attributes.length === 2) {
            if (classify2.filter((item)=>item.text != "").length === 0) {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_15__.toast.error("Vui l\xf2ng nhập chi tiết ph\xe2n loại 2");
                return;
            }
        }
        if (skus.some((item)=>item.file == null || item.price == "" || item.discount == "" || item.sku == "")) {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_15__.toast.error("Vui l\xf2ng nhập đầy đủ th\xf4ng tin biến thể");
            return;
        }
        newProduct.thumbnail = await (0,_utils__WEBPACK_IMPORTED_MODULE_14__/* .uploadImg */ .Ti)(thumbnail);
        const images = await Promise.all(skus.map((item)=>(0,_utils__WEBPACK_IMPORTED_MODULE_14__/* .uploadImg */ .Ti)(item.file)));
        dataTable.forEach((item, index)=>{
            newProduct.skuValue.push({
                detailAttributes: item.map((element)=>({
                        attributeId: element.attributeId,
                        name: element.text
                    })),
                price: skus[index].price,
                discount: skus[index].discount,
                sku: skus[index].skuPhanLoai,
                image: images[index]
            });
        });
        if (!newProduct.thumbnail) {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_15__.toast.error("Ảnh ch\xednh chưa hợp lệ, vui l\xf2ng chọn ảnh kh\xe1c");
            return;
        }
        mutate(newProduct);
    };
    const isExistElement = (array)=>{
        if (array.length > 0 && array[0].text != "") {
            return true;
        }
        return false;
    };
    const dataTable = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        const data = [];
        classify1.forEach((item)=>{
            if (item.text != "") {
                if (!isExistElement(classify2)) {
                    data.push([
                        item
                    ]);
                } else {
                    classify2.forEach((element)=>{
                        if (element.text != "") {
                            data.push([
                                item,
                                element
                            ]);
                        }
                    });
                }
            }
        });
        setSkus(data.map(()=>({
                price: "",
                discount: "",
                preview: "",
                file: null,
                skuPhanLoai: ""
            })));
        return data;
    }, [
        classify1,
        classify2
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Meta__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                image: "/images/logo.jpg",
                title: "Th\xeam sản phẩm | Admin",
                description: ""
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_AdminLayout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-5",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex items-center justify-between",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-white bg-primary px-4 py-2 inline rounded-lg",
                                children: "Th\xeam sản phẩm"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col md:flex-row mt-10",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "p-4 rounded-3xl flex flex-col md:flex-row w-full md:w-[60%]",
                                    style: {
                                        boxShadow: "rgba(0, 0, 0, 0.35) 0px 5px 15px"
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "w-full",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                className: "font-bold",
                                                children: "Th\xf4ng tin cơ bản"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "mt-5",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex items-center",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "w-[150px]",
                                                                children: "H\xecnh ảnh ch\xednh"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "ml-4 ",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                        type: "file",
                                                                        value: thumbnail?.preview || "",
                                                                        onChange: (e)=>{
                                                                            const file = e.target.files ? e.target.files[0] : null;
                                                                            if (file) {
                                                                                setPreview(URL.createObjectURL(file));
                                                                                setThumbnail(file);
                                                                            }
                                                                        },
                                                                        className: "hidden",
                                                                        name: "",
                                                                        id: "mainImage"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "mainImage",
                                                                        className: "cursor-pointer ",
                                                                        children: preview ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_12__.LazyLoadImage, {
                                                                            src: preview,
                                                                            className: "w-[40px] h-[40px]",
                                                                            effect: "blur"
                                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fc__WEBPACK_IMPORTED_MODULE_3__.FcAddImage, {
                                                                            fontSize: 40
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex items-center mt-2 ",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "w-[150px]",
                                                                children: "T\xean sản phẩm"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "flex-1 ml-4 ",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: " flex items-center border rounded-md",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_customs_TextField__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                                                control: control,
                                                                                error: errors,
                                                                                showError: false,
                                                                                rules: {
                                                                                    required: "Kh\xf4ng được để trống \xf4",
                                                                                    minLength: {
                                                                                        value: 10,
                                                                                        message: "T\xean sản phẩm của bạn qu\xe1 ngắn. Vui l\xf2ng nhập \xedt nhất 10 k\xed tự"
                                                                                    },
                                                                                    maxLength: {
                                                                                        value: 120,
                                                                                        message: "T\xean sản phẩm của bạn qu\xe1 d\xe0i. Vui l\xf2ng nhập tối đa 120 k\xed tự"
                                                                                    }
                                                                                },
                                                                                name: "name",
                                                                                placeholder: "Nhập v\xe0o",
                                                                                className: "w-full px-4 py-1 rounded-md outline-none"
                                                                            }),
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: "border-l px-2 text-[#666]",
                                                                                children: [
                                                                                    name.length,
                                                                                    "/",
                                                                                    maxLength
                                                                                ]
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                        className: "py-1 text-primary text-sm",
                                                                        children: errors["name"] && errors["name"].message
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "mt-2 flex items-center",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "w-[150px]",
                                                                children: "Thể loại"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "ml-4 flex-1",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_customs_Select__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                                    error: errors,
                                                                    name: "category",
                                                                    rules: {
                                                                        required: "Kh\xf4ng được để trống \xf4"
                                                                    },
                                                                    control: control,
                                                                    className: "px-4 h-[34px] outline-none border rounded-md w-full",
                                                                    data: categories.map((item)=>({
                                                                            value: item.id,
                                                                            text: item.name
                                                                        }))
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "mt-2 flex items-center",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "w-[150px]",
                                                                children: "M\xf4 tả sản phẩm"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "ml-4 flex-1",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_customs_TextArea__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                    control: control,
                                                                    error: errors,
                                                                    rules: {
                                                                        required: "Kh\xf4ng được để trống \xf4",
                                                                        minLength: {
                                                                            value: 10,
                                                                            message: "M\xf4 tả sản phẩm của bạn qu\xe1 ngắn. Vui l\xf2ng nhập \xedt nhất 10 k\xed tự"
                                                                        },
                                                                        maxLength: {
                                                                            value: 3000,
                                                                            message: "M\xf4 tả sản phẩm của bạn qu\xe1 d\xe0i. Vui l\xf2ng nhập tối đa 3000 k\xed tự"
                                                                        }
                                                                    },
                                                                    name: "description",
                                                                    placeholder: "Nhập v\xe0o",
                                                                    className: "w-full border px-4 py-1 rounded-md outline-none"
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "mt-2 flex items-center",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "w-[150px]",
                                                                children: "Ph\xe2n loại h\xe0ng"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "ml-4 flex-1",
                                                                children: [
                                                                    [
                                                                        groupClassify.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                className: " bg-gray-100 rounded-md relative p-2 flex-1 first:mt-0 mt-2",
                                                                                children: [
                                                                                    index > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                        onClick: ()=>setGroupClassify(groupClassify.filter((element, ind)=>element.id !== item.id)),
                                                                                        className: "absolute top-2 right-2 hover:cursor-pointer",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_8__.GrClose, {})
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "flex items-center text-[#666]",
                                                                                        children: [
                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                                className: "w-[100px]",
                                                                                                children: [
                                                                                                    "Nh\xf3m PL ",
                                                                                                    index + 1
                                                                                                ]
                                                                                            }),
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                value: item.text,
                                                                                                onChange: (e)=>setGroupClassify(groupClassify.map((element, ind)=>{
                                                                                                        if (element.id === item.id) {
                                                                                                            return {
                                                                                                                ...element,
                                                                                                                text: e.target.value
                                                                                                            };
                                                                                                        }
                                                                                                        return element;
                                                                                                    })),
                                                                                                type: "text",
                                                                                                className: "ml-4 w-full md:w-[50%] rounded-md px-2 py-1 border outline-none ",
                                                                                                placeholder: "v\xed dụ: m\xe0u sắc v.v"
                                                                                            })
                                                                                        ]
                                                                                    }),
                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "mt-2 flex items-center text-[#666]",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "w-[100px]",
                                                                                                children: "Ph\xe2n loại"
                                                                                            }),
                                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                className: "grid flex-1 ml-4 grid-cols-2 gap-1",
                                                                                                children: [
                                                                                                    index === 0 && classify1.map((element, ind)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                            className: "flex items-center first:ml-0",
                                                                                                            children: [
                                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                                    value: element.text,
                                                                                                                    onChange: (e)=>setClassify1(classify1.map((c)=>{
                                                                                                                            if (c.id === element.id) {
                                                                                                                                return {
                                                                                                                                    ...c,
                                                                                                                                    text: e.target.value
                                                                                                                                };
                                                                                                                            }
                                                                                                                            return c;
                                                                                                                        })),
                                                                                                                    type: "text",
                                                                                                                    className: "rounded-md px-2 py-1 border w-full outline-none",
                                                                                                                    placeholder: "v\xed dụ: trắng, đỏ v.v"
                                                                                                                }),
                                                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                                    className: "flex items-center",
                                                                                                                    children: [
                                                                                                                        ind === classify1.length - 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_9__.AiOutlinePlus, {
                                                                                                                            className: "cursor-pointer",
                                                                                                                            onClick: ()=>setClassify1([
                                                                                                                                    ...classify1,
                                                                                                                                    {
                                                                                                                                        attributeId: classify1[0].attributeId,
                                                                                                                                        id: (0,uuid__WEBPACK_IMPORTED_MODULE_10__.v4)(),
                                                                                                                                        text: ""
                                                                                                                                    }
                                                                                                                                ]),
                                                                                                                            fontSize: 20
                                                                                                                        }),
                                                                                                                        ind > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_9__.AiOutlineDelete, {
                                                                                                                            onClick: ()=>setClassify1(classify1.filter((c)=>c.id !== element.id)),
                                                                                                                            fontSize: 20,
                                                                                                                            className: "ml-1 cursor-pointer"
                                                                                                                        })
                                                                                                                    ]
                                                                                                                })
                                                                                                            ]
                                                                                                        }, element.id)),
                                                                                                    index === 1 && classify2.map((element, ind)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                            className: "flex items-center first:ml-0",
                                                                                                            children: [
                                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                                                    value: element.text,
                                                                                                                    onChange: (e)=>setClassify2(classify2.map((c)=>{
                                                                                                                            if (c.id === element.id) {
                                                                                                                                return {
                                                                                                                                    ...c,
                                                                                                                                    text: e.target.value
                                                                                                                                };
                                                                                                                            }
                                                                                                                            return c;
                                                                                                                        })),
                                                                                                                    type: "text",
                                                                                                                    className: "rounded-md px-2 py-1 border w-full outline-none",
                                                                                                                    placeholder: "v\xed dụ: trắng, đỏ v.v"
                                                                                                                }),
                                                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                                    className: "flex items-center",
                                                                                                                    children: [
                                                                                                                        ind === classify2.length - 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_9__.AiOutlinePlus, {
                                                                                                                            className: "cursor-pointer",
                                                                                                                            onClick: ()=>setClassify2([
                                                                                                                                    ...classify2,
                                                                                                                                    {
                                                                                                                                        id: (0,uuid__WEBPACK_IMPORTED_MODULE_10__.v4)(),
                                                                                                                                        text: "",
                                                                                                                                        attributeId: classify2[0].attributeId
                                                                                                                                    }
                                                                                                                                ]),
                                                                                                                            fontSize: 20
                                                                                                                        }),
                                                                                                                        ind > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_9__.AiOutlineDelete, {
                                                                                                                            onClick: ()=>setClassify2(classify2.filter((c)=>c.id !== element.id)),
                                                                                                                            fontSize: 20,
                                                                                                                            className: "ml-1 cursor-pointer"
                                                                                                                        })
                                                                                                                    ]
                                                                                                                })
                                                                                                            ]
                                                                                                        }, element.id))
                                                                                                ]
                                                                                            })
                                                                                        ]
                                                                                    })
                                                                                ]
                                                                            }, index))
                                                                    ],
                                                                    groupClassify.length === 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                        onClick: ()=>{
                                                                            const newId = (0,uuid__WEBPACK_IMPORTED_MODULE_10__.v4)();
                                                                            setGroupClassify([
                                                                                ...groupClassify,
                                                                                {
                                                                                    id: newId,
                                                                                    text: ""
                                                                                }
                                                                            ]);
                                                                            setClassify2(classify2.map((item)=>({
                                                                                    ...item,
                                                                                    attributeId: newId
                                                                                })));
                                                                        },
                                                                        className: "mt-2 border rounded-sm px-4 py-1 text-primary hover:cursor-pointer hover:bg-gray-100",
                                                                        children: "Th\xeam nh\xf3m ph\xe2n loại 2"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "mt-4 flex justify-end",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            onClick: handleSubmit(handleAdd),
                                                            className: "text-white bg-primary py-1 rounded-md w-[150px]",
                                                            children: "Lưu sản phẩm"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "p-4 rounded-3xl mt-4 md:mt-0 flex flex-col md:flex-row w-full md:w-[40%] md:ml-4",
                                    style: {
                                        boxShadow: "rgba(0, 0, 0, 0.35) 0px 5px 15px"
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                className: "font-bold",
                                                children: "Th\xf4ng tin biến thể"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "mt-5",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_admin_products_TableProductAdmin__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                    skus: skus,
                                                    handleChange: (data)=>setSkus(data),
                                                    dataTable: dataTable,
                                                    classify1: classify1,
                                                    classify2: classify2,
                                                    groupClassify: groupClassify
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddProduct);
const getServerSideProps = async ({ req  })=>{
    const categories = await _actions_Category_action__WEBPACK_IMPORTED_MODULE_13__/* ["default"].getAll */ .Z.getAll();
    const detailActions = JSON.parse(req.cookies["detailActions"] || "[]");
    if (detailActions.includes("product:add")) {
        return {
            props: {
                categories
            }
        };
    }
    return {
        props: {},
        redirect: {
            destination: "/admin"
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8982:
/***/ ((module) => {

module.exports = require("cookies-next");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 7840:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 178:
/***/ ((module) => {

module.exports = require("react-icons/fc");

/***/ }),

/***/ 8547:
/***/ ((module) => {

module.exports = require("react-icons/gr");

/***/ }),

/***/ 4152:
/***/ ((module) => {

module.exports = require("react-icons/tb");

/***/ }),

/***/ 1740:
/***/ ((module) => {

module.exports = require("react-icons/tfi");

/***/ }),

/***/ 382:
/***/ ((module) => {

module.exports = require("react-icons/vsc");

/***/ }),

/***/ 9252:
/***/ ((module) => {

module.exports = require("react-lazy-load-image-component");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9752:
/***/ ((module) => {

module.exports = import("@tanstack/react-query");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 6201:
/***/ ((module) => {

module.exports = import("react-hot-toast");;

/***/ }),

/***/ 6555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,676,664,183,154,506,361,231,408,220,216,426,320], () => (__webpack_exec__(4525)));
module.exports = __webpack_exports__;

})();