"use strict";
(() => {
var exports = {};
exports.id = 630;
exports.ids = [630];
exports.modules = {

/***/ 3113:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_axiosClient__WEBPACK_IMPORTED_MODULE_0__]);
_config_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const CategoryAction = {
    getAll: async ()=>{
        try {
            const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/category");
            return result.data;
        } catch (error) {
            console.log(error);
            return [];
        }
    },
    add: async (data)=>{
        const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/category", data);
        return result.data;
    },
    update: async (data)=>{
        const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].put */ .Z.put(`/category/${data.id}`, data);
        return result.data;
    },
    delete: async (id)=>{
        const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/category/${id}`);
        return result.data;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoryAction);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5277:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_axiosClient__WEBPACK_IMPORTED_MODULE_0__]);
_config_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const PopularAction = {
    getAll: async ()=>{
        try {
            const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/popular");
            return result.data;
        } catch (error) {
            console.log(error);
            return [];
        }
    },
    popular: async (productId)=>{
        const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/popular`, {
            productId
        });
        return result.data;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PopularAction);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3553:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_axiosClient__WEBPACK_IMPORTED_MODULE_0__]);
_config_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const SkuAction = {
    getAll: async ()=>{
        try {
            const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/sku");
            return result.data;
        } catch (error) {
            console.log(error);
            return [];
        }
    },
    delete: async (id)=>{
        const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/sku/${id}`);
        return result;
    },
    update: async (data)=>{
        const result = await _config_axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].put */ .Z.put(`/sku/${data.id}`, {
            ...data,
            id: undefined
        });
        return result.data;
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SkuAction);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2396:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9752);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6201);
/* harmony import */ var _actions_Category_action__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3113);
/* harmony import */ var _customs_Select__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1426);
/* harmony import */ var _customs_TextField__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6220);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_Category_action__WEBPACK_IMPORTED_MODULE_6__, _customs_Select__WEBPACK_IMPORTED_MODULE_7__, _customs_TextField__WEBPACK_IMPORTED_MODULE_8__]);
([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_Category_action__WEBPACK_IMPORTED_MODULE_6__, _customs_Select__WEBPACK_IMPORTED_MODULE_7__, _customs_TextField__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const ModalAddCategory = ({ handleClose , open , data  })=>{
    const { control , formState: { errors  } , handleSubmit , getValues , watch , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        defaultValues: {
            name: "",
            speciesId: ""
        }
    });
    const queryClient = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQueryClient)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { mutate , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(_actions_Category_action__WEBPACK_IMPORTED_MODULE_6__/* ["default"].add */ .Z.add, {
        onSuccess: (data)=>{
            const dataCategoriesOld = queryClient.getQueryData([
                "categories",
                router.asPath
            ]) || [];
            queryClient.setQueryData([
                "categories",
                router.asPath
            ], [
                data,
                ...dataCategoriesOld
            ]);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success("Th\xeam th\xe0nh c\xf4ng");
            handleClose();
            reset();
        },
        onError: (err)=>{
            console.log(err);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("C\xf3 lỗi xảy ra, vui l\xf2ng thử lại");
        }
    });
    const handleUpdate = (data)=>{
        mutate(data);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${!open && "hidden"} `,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "fixed inset-0 bg-[rgba(0,0,0,0.6)] z-[60]",
                onClick: handleClose
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-[90%] md:w-[500px] p-4 rounded-lg bg-white fixed z-[70] top-[50%] translate-y-[-50%] translate-x-[-50%] left-[50%] ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold",
                        children: "Th\xeam thể loại"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-4 space-y-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "T\xean thể loại"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_TextField__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                        control: control,
                                        error: errors,
                                        name: "name",
                                        className: "css-field",
                                        placeholder: "Nhập v\xe0o",
                                        rules: {
                                            required: "Kh\xf4ng được để trống \xf4",
                                            maxLength: {
                                                value: 120,
                                                message: "T\xean thể loại của bạn qu\xe1 d\xe0i. Vui l\xf2ng nhập tối đa 120 k\xed tự"
                                            }
                                        }
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "Chủng loại"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_Select__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        control: control,
                                        data: data?.map((item)=>({
                                                text: item.name,
                                                value: item.id
                                            })),
                                        rules: {
                                            required: "Kh\xf4ng được để trống \xf4"
                                        },
                                        error: errors,
                                        name: "speciesId",
                                        className: "css-field"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-4 flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                disabled: isLoading,
                                onClick: handleClose,
                                type: "button",
                                className: "text-gray-500 bg-gray-100 hover:bg-gray-300 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600",
                                children: "Đ\xf3ng"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                disabled: isLoading,
                                onClick: handleSubmit(handleUpdate),
                                className: "text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800",
                                children: "Lưu"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModalAddCategory);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8339:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9752);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6201);
/* harmony import */ var react_icons_fc__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(178);
/* harmony import */ var react_icons_fc__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_fc__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9252);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _actions_Species_action__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2701);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9361);
/* harmony import */ var _customs_TextField__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6220);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_Species_action__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__, _customs_TextField__WEBPACK_IMPORTED_MODULE_10__]);
([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_Species_action__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__, _customs_TextField__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const ModalAddSpecies = ({ handleClose , open  })=>{
    const { control , formState: { errors  } , handleSubmit , getValues , watch , setValue , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        defaultValues: {
            name: ""
        }
    });
    const queryClient = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQueryClient)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const [thumbnail, setThumbnail] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [preview, setPreview] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const { mutate , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(_actions_Species_action__WEBPACK_IMPORTED_MODULE_8__/* ["default"].add */ .Z.add, {
        onSuccess: (data)=>{
            const dataSpeciesOld = queryClient.getQueryData([
                "species",
                router.asPath
            ]) || [];
            queryClient.setQueryData([
                "species",
                router.asPath
            ], [
                data,
                ...dataSpeciesOld
            ]);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success("Th\xeam th\xe0nh c\xf4ng");
            handleClose();
            reset();
        },
        onError: (err)=>{
            console.log(err);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("C\xf3 lỗi xảy ra, vui l\xf2ng thử lại");
        }
    });
    const handleUpdate = async (data)=>{
        if (!thumbnail) {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("Vui l\xf2ng chọn ảnh");
            return;
        }
        const image = await (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .uploadImg */ .Ti)(thumbnail);
        mutate({
            ...data,
            thumbnail: image
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${!open && "hidden"} `,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "fixed inset-0 bg-[rgba(0,0,0,0.6)] z-[60]",
                onClick: handleClose
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-[90%] md:w-[500px] p-4 rounded-lg bg-white fixed z-[70] top-[50%] translate-y-[-50%] translate-x-[-50%] left-[50%] ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold",
                        children: "Th\xeam chủng loại"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-4 space-y-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center space-x-2 mb-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "H\xecnh ảnh"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "file",
                                                onChange: (e)=>{
                                                    const files = e.target && e.target.files && e.target.files[0] || undefined;
                                                    setThumbnail(files);
                                                    files && setPreview(URL.createObjectURL(files));
                                                },
                                                className: "hidden",
                                                accept: "image/*",
                                                id: "mainImage"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mainImage",
                                                children: preview ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_7__.LazyLoadImage, {
                                                    alt: "",
                                                    width: 60,
                                                    height: "60",
                                                    src: preview
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fc__WEBPACK_IMPORTED_MODULE_6__.FcAddImage, {
                                                    fontSize: 40
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "T\xean chủng loại"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_TextField__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                        control: control,
                                        error: errors,
                                        name: "name",
                                        className: "css-field",
                                        placeholder: "Nhập v\xe0o",
                                        rules: {
                                            required: "Kh\xf4ng được để trống \xf4",
                                            minLength: {
                                                value: 5,
                                                message: "T\xean thể loại của bạn qu\xe1 ngắn. Vui l\xf2ng nhập \xedt nhất 5 k\xed tự"
                                            },
                                            maxLength: {
                                                value: 120,
                                                message: "T\xean thể loại của bạn qu\xe1 d\xe0i. Vui l\xf2ng nhập tối đa 120 k\xed tự"
                                            }
                                        }
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-4 flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                disabled: isLoading,
                                onClick: handleClose,
                                type: "button",
                                className: "text-gray-500 bg-gray-100 hover:bg-gray-300 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600",
                                children: "Đ\xf3ng"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                disabled: isLoading,
                                onClick: handleSubmit(handleUpdate),
                                className: "text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800",
                                children: "Lưu"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModalAddSpecies);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7652:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9752);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6201);
/* harmony import */ var _actions_Category_action__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3113);
/* harmony import */ var _customs_Select__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1426);
/* harmony import */ var _customs_TextField__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6220);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_Category_action__WEBPACK_IMPORTED_MODULE_6__, _customs_Select__WEBPACK_IMPORTED_MODULE_7__, _customs_TextField__WEBPACK_IMPORTED_MODULE_8__]);
([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_Category_action__WEBPACK_IMPORTED_MODULE_6__, _customs_Select__WEBPACK_IMPORTED_MODULE_7__, _customs_TextField__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const ModalUpdateCategory = ({ handleClose , open , data , current  })=>{
    const { control , formState: { errors  } , handleSubmit , getValues , watch , setValue  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        defaultValues: {
            name: "",
            speciesId: ""
        }
    });
    const queryClient = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQueryClient)();
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setValue("name", current?.name);
        setValue("speciesId", current?.speciesId.toString());
    }, [
        current
    ]);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { mutate , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(_actions_Category_action__WEBPACK_IMPORTED_MODULE_6__/* ["default"].update */ .Z.update, {
        onSuccess: (data)=>{
            const dataCategoriesOld = queryClient.getQueryData([
                "categories",
                router.asPath
            ]) || [];
            queryClient.setQueryData([
                "categories",
                router.asPath
            ], dataCategoriesOld.map((item)=>{
                if (item.id === data.id) {
                    return data;
                }
                return item;
            }));
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success("Cập nhật th\xe0nh c\xf4ng");
            handleClose();
        },
        onError: (err)=>{
            console.log(err);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("C\xf3 lỗi xảy ra, vui l\xf2ng thử lại");
        }
    });
    const handleUpdate = (data)=>{
        mutate({
            ...data,
            id: current?.id
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${!open && "hidden"} `,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "fixed inset-0 bg-[rgba(0,0,0,0.6)] z-[60]",
                onClick: handleClose
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-[90%] md:w-[500px] p-4 rounded-lg bg-white fixed z-[70] top-[50%] translate-y-[-50%] translate-x-[-50%] left-[50%] ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold",
                        children: "Cập nhật thể loại"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-4 space-y-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "T\xean thể loại"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_TextField__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                        control: control,
                                        error: errors,
                                        name: "name",
                                        className: "css-field",
                                        placeholder: "Nhập v\xe0o",
                                        rules: {
                                            required: "Kh\xf4ng được để trống \xf4",
                                            minLength: {
                                                value: 5,
                                                message: "T\xean thể loại của bạn qu\xe1 ngắn. Vui l\xf2ng nhập \xedt nhất 5 k\xed tự"
                                            },
                                            maxLength: {
                                                value: 120,
                                                message: "T\xean thể loại của bạn qu\xe1 d\xe0i. Vui l\xf2ng nhập tối đa 120 k\xed tự"
                                            }
                                        }
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "Chủng loại"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_Select__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        control: control,
                                        data: data?.map((item)=>({
                                                text: item.name,
                                                value: item.id
                                            })),
                                        rules: {
                                            required: "Kh\xf4ng được để trống \xf4"
                                        },
                                        error: errors,
                                        name: "speciesId",
                                        className: "css-field"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-4 flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                disabled: isLoading,
                                onClick: handleClose,
                                type: "button",
                                className: "text-gray-500 bg-gray-100 hover:bg-gray-300 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600",
                                children: "Đ\xf3ng"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                disabled: isLoading,
                                onClick: handleSubmit(handleUpdate),
                                className: "text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800",
                                children: "Lưu"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModalUpdateCategory);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6622:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9752);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6201);
/* harmony import */ var react_icons_fc__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(178);
/* harmony import */ var react_icons_fc__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_fc__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9252);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _actions_Product_action__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5183);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9361);
/* harmony import */ var _customs_Select__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1426);
/* harmony import */ var _customs_TextArea__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2216);
/* harmony import */ var _customs_TextField__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6220);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_Product_action__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__, _customs_Select__WEBPACK_IMPORTED_MODULE_10__, _customs_TextArea__WEBPACK_IMPORTED_MODULE_11__, _customs_TextField__WEBPACK_IMPORTED_MODULE_12__]);
([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_Product_action__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__, _customs_Select__WEBPACK_IMPORTED_MODULE_10__, _customs_TextArea__WEBPACK_IMPORTED_MODULE_11__, _customs_TextField__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const ModalUpdateProduct = ({ handleClose , open , current , categories  })=>{
    const [file, setFile] = react__WEBPACK_IMPORTED_MODULE_3___default().useState();
    const [preview, setPreview] = react__WEBPACK_IMPORTED_MODULE_3___default().useState("");
    const { control , formState: { errors  } , handleSubmit , getValues , watch , setValue  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        defaultValues: {
            name: "",
            categoryId: 0,
            description: ""
        }
    });
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (current) {
            setValue("name", current.name);
            setValue("categoryId", current.categoryId);
            setValue("description", current.description);
            setPreview((0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .getImageServer */ .KT)(current.thumbnail));
        }
    }, [
        current
    ]);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const queryClient = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQueryClient)();
    const { mutate , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(_actions_Product_action__WEBPACK_IMPORTED_MODULE_8__/* ["default"].update */ .Z.update, {
        onSuccess: (data, variables)=>{
            const dataProductOld = queryClient.getQueryData([
                "products",
                router.asPath
            ]) || [];
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success("Cập nhật th\xe0nh c\xf4ng");
            handleClose();
            queryClient.setQueryData([
                "products",
                router.asPath
            ], dataProductOld.map((item)=>{
                if (item.id === variables.id) {
                    return data;
                }
                return item;
            }));
        },
        onError: (err)=>{
            console.log(err);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("C\xf3 lỗi xảy ra, vui l\xf2ng thử lại");
        }
    });
    const handleUpdate = async (data)=>{
        let image = "";
        if (file) {
            image = await (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .uploadImg */ .Ti)(file);
        } else {
            image = preview.split("images/")[1];
        }
        mutate({
            ...data,
            id: current.id,
            thumbnail: image
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${!open && "hidden"} `,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "fixed inset-0 bg-[rgba(0,0,0,0.6)] z-[60]",
                onClick: handleClose
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-[90%] md:w-[500px] p-4 rounded-lg bg-white fixed z-[70] top-[50%] translate-y-[-50%] translate-x-[-50%] left-[50%] ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold",
                        children: "Cập nhật sản phẩm"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-4 space-y-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center space-x-2 mb-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "H\xecnh ảnh"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "file",
                                                onChange: (e)=>{
                                                    const files = e.target && e.target.files && e.target.files[0];
                                                    setFile(files);
                                                    files && setPreview(URL.createObjectURL(files));
                                                },
                                                className: "hidden",
                                                accept: "image/*",
                                                id: "mainImage"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mainImage",
                                                children: preview ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_7__.LazyLoadImage, {
                                                    alt: "",
                                                    width: 60,
                                                    height: "60",
                                                    src: preview
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fc__WEBPACK_IMPORTED_MODULE_6__.FcAddImage, {
                                                    fontSize: 40
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "T\xean sản phẩm"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_TextField__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                        control: control,
                                        error: errors,
                                        name: "name",
                                        className: "css-field",
                                        placeholder: "Nhập v\xe0o",
                                        rules: {
                                            required: "Kh\xf4ng được để trống \xf4",
                                            minLength: {
                                                value: 10,
                                                message: "T\xean sản phẩm của bạn qu\xe1 ngắn. Vui l\xf2ng nhập \xedt nhất 10 k\xed tự"
                                            },
                                            maxLength: {
                                                value: 120,
                                                message: "T\xean sản phẩm của bạn qu\xe1 d\xe0i. Vui l\xf2ng nhập tối đa 120 k\xed tự"
                                            }
                                        }
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "Thể loại"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_Select__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                        control: control,
                                        data: categories?.map((item)=>({
                                                text: item.name,
                                                value: item.id
                                            })),
                                        error: errors,
                                        name: "categoryId",
                                        className: "css-field"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "M\xf4 tả sản phẩm"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_TextArea__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                        control: control,
                                        error: errors,
                                        name: "description",
                                        className: "css-field",
                                        placeholder: "Nhập v\xe0o",
                                        rules: {
                                            required: "Kh\xf4ng được để trống \xf4",
                                            minLength: {
                                                value: 10,
                                                message: "T\xean sản phẩm của bạn qu\xe1 ngắn. Vui l\xf2ng nhập \xedt nhất 100 k\xed tự"
                                            },
                                            maxLength: {
                                                value: 3000,
                                                message: "T\xean sản phẩm của bạn qu\xe1 d\xe0i. Vui l\xf2ng nhập tối đa 3000 k\xed tự"
                                            }
                                        }
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-4 flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: handleClose,
                                type: "button",
                                className: "text-gray-500 bg-gray-100 hover:bg-gray-300 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600",
                                children: "Đ\xf3ng"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: handleSubmit(handleUpdate),
                                className: "text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800",
                                children: "Cập nhật"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModalUpdateProduct);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6772:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9752);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6201);
/* harmony import */ var react_icons_fc__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(178);
/* harmony import */ var react_icons_fc__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_fc__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9252);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _actions_Sku_action__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3553);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9361);
/* harmony import */ var _customs_TextField__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6220);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_Sku_action__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__, _customs_TextField__WEBPACK_IMPORTED_MODULE_10__]);
([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_Sku_action__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__, _customs_TextField__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const ModalUpdateSku = ({ handleClose , open , current  })=>{
    const [file, setFile] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [preview, setPreview] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const queryClient = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQueryClient)();
    const { control , formState: { errors  } , handleSubmit , getValues , watch , setValue  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        defaultValues: {
            price: 0,
            discount: 0,
            sku: ""
        }
    });
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setValue("price", current?.price);
        setValue("discount", current?.discount);
        setValue("sku", current?.sku);
        setPreview((0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .getImageServer */ .KT)(current?.image));
    }, [
        current
    ]);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { mutate , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(_actions_Sku_action__WEBPACK_IMPORTED_MODULE_8__/* ["default"].update */ .Z.update, {
        onSuccess: (data)=>{
            const dataSkuOld = queryClient.getQueryData([
                "skus",
                router.asPath
            ]) || [];
            queryClient.setQueryData([
                "skus",
                router.asPath
            ], dataSkuOld.map((item)=>{
                if (item.id === data.id) {
                    return data;
                }
                return item;
            }));
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success("Cập nhật th\xe0nh c\xf4ng");
            handleClose();
        },
        onError: (err)=>{
            console.log(err);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("C\xf3 lỗi xảy ra, vui l\xf2ng thử lại");
        }
    });
    const handleUpdate = async (data)=>{
        let image = preview;
        if (file) {
            image = await (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .uploadImg */ .Ti)(file);
        }
        mutate({
            ...data,
            id: current?.id,
            image: image.split("images/")[1]
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${!open && "hidden"} `,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "fixed inset-0 bg-[rgba(0,0,0,0.6)] z-[60]",
                onClick: handleClose
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-[90%] md:w-[500px] p-4 rounded-lg bg-white fixed z-[70] top-[50%] translate-y-[-50%] translate-x-[-50%] left-[50%] ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold",
                        children: "Cập nhật h\xe0ng h\xf3a"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-4 space-y-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "w-[150px]",
                                        children: "H\xecnh ảnh"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "ml-4 ",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "file",
                                                onChange: (e)=>{
                                                    const file = e.target.files ? e.target.files[0] : null;
                                                    if (file) {
                                                        setPreview(URL.createObjectURL(file));
                                                        setFile(file);
                                                    }
                                                },
                                                accept: "image/*",
                                                className: "hidden",
                                                name: "",
                                                id: "mainImage"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mainImage",
                                                className: "cursor-pointer ",
                                                children: preview ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_7__.LazyLoadImage, {
                                                    src: preview,
                                                    className: "w-[40px] h-[40px]",
                                                    effect: "blur"
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fc__WEBPACK_IMPORTED_MODULE_6__.FcAddImage, {
                                                    fontSize: 40
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "SKU"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_TextField__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                        control: control,
                                        error: errors,
                                        name: "sku",
                                        className: "css-field",
                                        placeholder: "Nhập v\xe0o",
                                        rules: {
                                            required: "Kh\xf4ng được để trống \xf4"
                                        }
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "Gi\xe1 h\xe0ng h\xf3a"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_TextField__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                        control: control,
                                        error: errors,
                                        name: "price",
                                        className: "css-field",
                                        placeholder: "Nhập v\xe0o",
                                        rules: {
                                            required: "Kh\xf4ng được để trống \xf4",
                                            pattern: {
                                                value: /^(0|[1-9]\d*)(\.\d+)?$/,
                                                message: "Trường n\xe0y phải l\xe0 số"
                                            }
                                        }
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "% giảm"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_TextField__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                        control: control,
                                        error: errors,
                                        name: "discount",
                                        className: "css-field",
                                        placeholder: "Nhập v\xe0o",
                                        rules: {
                                            required: "Kh\xf4ng được để trống \xf4",
                                            pattern: {
                                                value: /^(0|[1-9]\d*)(\.\d+)?$/,
                                                message: "Trường n\xe0y phải l\xe0 số"
                                            }
                                        }
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-4 flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                disabled: isLoading,
                                onClick: handleClose,
                                type: "button",
                                className: "text-gray-500 bg-gray-100 hover:bg-gray-300 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600",
                                children: "Đ\xf3ng"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                disabled: isLoading,
                                onClick: handleSubmit(handleUpdate),
                                className: "text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800",
                                children: "Lưu"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModalUpdateSku);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4844:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9752);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6201);
/* harmony import */ var react_icons_fc__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(178);
/* harmony import */ var react_icons_fc__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_fc__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9252);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _actions_Species_action__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2701);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9361);
/* harmony import */ var _customs_TextField__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6220);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_Species_action__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__, _customs_TextField__WEBPACK_IMPORTED_MODULE_10__]);
([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_Species_action__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__, _customs_TextField__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const ModalUpdateSpecies = ({ handleClose , open , current  })=>{
    const { control , formState: { errors  } , handleSubmit , getValues , watch , setValue  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        defaultValues: {
            name: ""
        }
    });
    const [thumbnail, setThumbnail] = react__WEBPACK_IMPORTED_MODULE_3___default().useState();
    const [preview, setPreview] = react__WEBPACK_IMPORTED_MODULE_3___default().useState("");
    const queryClient = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQueryClient)();
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setValue("name", current?.name);
        if (current?.thumbnail) {
            setPreview((0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .getImageServer */ .KT)(current.thumbnail));
        }
    }, [
        current
    ]);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { mutate , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(_actions_Species_action__WEBPACK_IMPORTED_MODULE_8__/* ["default"].update */ .Z.update, {
        onSuccess: (data)=>{
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success("Cập nhật th\xe0nh c\xf4ng");
            const dataSpeciesOld = queryClient.getQueryData([
                "species",
                router.asPath
            ]) || [];
            queryClient.setQueryData([
                "species",
                router.asPath
            ], dataSpeciesOld.map((item)=>{
                if (item.id === data.id) {
                    return data;
                }
                return item;
            }));
            handleClose();
        },
        onError: (err)=>{
            console.log(err);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("C\xf3 lỗi xảy ra, vui l\xf2ng thử lại");
        }
    });
    const handleUpdate = async (data)=>{
        let image = "";
        if (thumbnail) {
            image = await (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .uploadImg */ .Ti)(thumbnail);
        } else {
            image = preview.split("images/")[1];
        }
        mutate({
            ...data,
            id: current?.id,
            thumbnail: image
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${!open && "hidden"} `,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "fixed inset-0 bg-[rgba(0,0,0,0.6)] z-[60]",
                onClick: handleClose
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-[90%] md:w-[500px] p-4 rounded-lg bg-white fixed z-[70] top-[50%] translate-y-[-50%] translate-x-[-50%] left-[50%] ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-bold",
                        children: "Cập nhật chủng loại"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-4 space-y-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center space-x-2 mb-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "H\xecnh ảnh"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "file",
                                                onChange: (e)=>{
                                                    const files = e.target && e.target.files && e.target.files[0];
                                                    setThumbnail(files || undefined);
                                                    files && setPreview(URL.createObjectURL(files));
                                                },
                                                className: "hidden",
                                                accept: "image/*",
                                                id: "mainImage"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mainImage",
                                                children: preview ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_7__.LazyLoadImage, {
                                                    alt: "",
                                                    width: 60,
                                                    height: "60",
                                                    src: preview
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fc__WEBPACK_IMPORTED_MODULE_6__.FcAddImage, {
                                                    fontSize: 40
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        children: "T\xean chủng loại"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customs_TextField__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                        control: control,
                                        error: errors,
                                        name: "name",
                                        className: "css-field",
                                        placeholder: "Nhập v\xe0o",
                                        rules: {
                                            required: "Kh\xf4ng được để trống \xf4",
                                            minLength: {
                                                value: 5,
                                                message: "T\xean thể loại của bạn qu\xe1 ngắn. Vui l\xf2ng nhập \xedt nhất 5 k\xed tự"
                                            },
                                            maxLength: {
                                                value: 120,
                                                message: "T\xean thể loại của bạn qu\xe1 d\xe0i. Vui l\xf2ng nhập tối đa 120 k\xed tự"
                                            }
                                        }
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-4 flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                disabled: isLoading,
                                onClick: handleClose,
                                type: "button",
                                className: "text-gray-500 bg-gray-100 hover:bg-gray-300 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600",
                                children: "Đ\xf3ng"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                disabled: isLoading,
                                onClick: handleSubmit(handleUpdate),
                                className: "text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800",
                                children: "Lưu"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModalUpdateSpecies);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1713:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9752);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6201);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8625);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_ci__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var sweetalert__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4701);
/* harmony import */ var sweetalert__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(sweetalert__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _actions_Category_action__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3113);
/* harmony import */ var _actions_Species_action__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2701);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(506);
/* harmony import */ var _LoadingSpinner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3595);
/* harmony import */ var _ModalAddCategory__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2396);
/* harmony import */ var _ModalUpdateCategory__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7652);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_Category_action__WEBPACK_IMPORTED_MODULE_9__, _actions_Species_action__WEBPACK_IMPORTED_MODULE_10__, _context__WEBPACK_IMPORTED_MODULE_11__, _ModalAddCategory__WEBPACK_IMPORTED_MODULE_13__, _ModalUpdateCategory__WEBPACK_IMPORTED_MODULE_14__]);
([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hot_toast__WEBPACK_IMPORTED_MODULE_5__, _actions_Category_action__WEBPACK_IMPORTED_MODULE_9__, _actions_Species_action__WEBPACK_IMPORTED_MODULE_10__, _context__WEBPACK_IMPORTED_MODULE_11__, _ModalAddCategory__WEBPACK_IMPORTED_MODULE_13__, _ModalUpdateCategory__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const PCategoryAdmin = ()=>{
    const [openModalAdd, setOpenModalAdd] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [openModalUpdate, setOpenModalUpdate] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const { data: species , isLoading: isLoadingSpecies  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)([
        "species",
        router.asPath
    ], ()=>_actions_Species_action__WEBPACK_IMPORTED_MODULE_10__/* ["default"].getAll */ .Z.getAll(0));
    const { data: categories , isLoading: isLoadingCategory  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)([
        "categories",
        router.asPath
    ], _actions_Category_action__WEBPACK_IMPORTED_MODULE_9__/* ["default"].getAll */ .Z.getAll);
    const queryClient = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQueryClient)();
    const { mutate , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(_actions_Category_action__WEBPACK_IMPORTED_MODULE_9__/* ["default"]["delete"] */ .Z["delete"], {
        onSuccess: (data, variable)=>{
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.success("Đ\xe3 chuyển v\xe0o th\xf9ng r\xe1c");
            queryClient.setQueryData([
                "categories",
                router.asPath
            ], categories?.filter((item)=>item.id !== variable));
        },
        onError: (err)=>{
            console.log(err);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_5__.toast.error("C\xf3 lỗi xảy ra, vui l\xf2ng thử lại");
        }
    });
    const handleDelete = (id)=>{
        sweetalert__WEBPACK_IMPORTED_MODULE_8___default()({
            title: "Bạn c\xf3 chắc chắn muốn x\xf3a?",
            text: "Khi x\xf3a, đối tượng sẽ được chuyển v\xe0o th\xf9ng r\xe1c",
            icon: "warning",
            buttons: [
                "Hủy",
                "X\xf3a"
            ],
            dangerMode: true
        }).then((willDelete)=>{
            if (willDelete) {
                mutate(id);
            }
        });
    };
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_context__WEBPACK_IMPORTED_MODULE_11__/* .AuthContext */ .V);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-5 grid",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-white bg-primary px-4 py-2 inline rounded-lg",
                                children: "Quản l\xfd thể loại"
                            }),
                            user?.detailActions.includes("category:add") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>setOpenModalAdd(true),
                                className: "px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-700",
                                children: "Th\xeam thể loại"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mt-4 bg-white rounded-3xl p-4 max-h-[450px] overflow-scroll shadow-master",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "relative",
                            children: !isLoadingCategory ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                className: "table-auto w-full text-sm text-left text-gray-500 dark:text-gray-400",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                        className: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "M\xe3 thể loại"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "T\xean thể loại"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "Chủng loại"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "Ng\xe0y cập nhật"
                                                }),
                                                (user?.detailActions.includes("category:update") || user?.detailActions.includes("category:delete")) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "H\xe0nh động"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                        children: categories?.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                className: "bg-white border-b dark:bg-gray-800 dark:border-gray-700",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        scope: "row",
                                                        className: "py-4 px-6 font-medium text-gray-900 whitespace-nowrap dark:text-white",
                                                        children: item.id
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-4 px-6 break-words max-w-[300px]",
                                                        children: item.name
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-4 px-6 break-words max-w-[300px]",
                                                        children: item?.species?.name
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-4 px-6",
                                                        children: dayjs__WEBPACK_IMPORTED_MODULE_2___default()(item.createdAt).format("DD/MM/YYYY")
                                                    }),
                                                    (user?.detailActions.includes("category:update") || user?.detailActions.includes("category:delete")) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-4 px-6",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "flex",
                                                            children: [
                                                                user?.detailActions.includes("category:update") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    onClick: ()=>{
                                                                        setCurrent(item);
                                                                        setOpenModalUpdate(true);
                                                                    },
                                                                    className: "bg-primary flex items-center justify-center text-white p-1 rounded-md hover:bg-primaryHover cursor-pointer",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ci__WEBPACK_IMPORTED_MODULE_6__.CiEdit, {
                                                                        fontSize: 24
                                                                    })
                                                                }),
                                                                user?.detailActions.includes("category:delete") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    onClick: ()=>handleDelete(item.id),
                                                                    className: "ml-2 bg-red-500 flex items-center justify-center text-white p-1 rounded-md hover:bg-red-700 cursor-pointer",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_7__.RiDeleteBin6Line, {
                                                                        fontSize: 24
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }, item.id))
                                    })
                                ]
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex items-center justify-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LoadingSpinner__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                    isFullScreen: false
                                })
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalAddCategory__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                open: openModalAdd,
                handleClose: ()=>setOpenModalAdd(false),
                data: species || []
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalUpdateCategory__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                open: openModalUpdate,
                handleClose: ()=>setOpenModalUpdate(false),
                data: species || [],
                current: current
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PCategoryAdmin);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1165:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9752);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6201);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8625);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_ci__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9252);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var sweetalert__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4701);
/* harmony import */ var sweetalert__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(sweetalert__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _actions_Category_action__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3113);
/* harmony import */ var _actions_Popular_action__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5277);
/* harmony import */ var _actions_Product_action__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5183);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9361);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(506);
/* harmony import */ var _LoadingSpinner__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3595);
/* harmony import */ var _SearchAdmin__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2466);
/* harmony import */ var _ModalUpdateProduct__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(6622);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hot_toast__WEBPACK_IMPORTED_MODULE_6__, _actions_Category_action__WEBPACK_IMPORTED_MODULE_12__, _actions_Popular_action__WEBPACK_IMPORTED_MODULE_13__, _actions_Product_action__WEBPACK_IMPORTED_MODULE_14__, _utils__WEBPACK_IMPORTED_MODULE_15__, _context__WEBPACK_IMPORTED_MODULE_16__, _ModalUpdateProduct__WEBPACK_IMPORTED_MODULE_19__]);
([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hot_toast__WEBPACK_IMPORTED_MODULE_6__, _actions_Category_action__WEBPACK_IMPORTED_MODULE_12__, _actions_Popular_action__WEBPACK_IMPORTED_MODULE_13__, _actions_Product_action__WEBPACK_IMPORTED_MODULE_14__, _utils__WEBPACK_IMPORTED_MODULE_15__, _context__WEBPACK_IMPORTED_MODULE_16__, _ModalUpdateProduct__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




















const ProductAdmin = ()=>{
    const [openModal, setOpenModal] = react__WEBPACK_IMPORTED_MODULE_5___default().useState(false);
    const [current, setCurrent] = react__WEBPACK_IMPORTED_MODULE_5___default().useState();
    const [currentProduct, setCurrentProduct] = react__WEBPACK_IMPORTED_MODULE_5___default().useState([]);
    const [search, setSearch] = react__WEBPACK_IMPORTED_MODULE_5___default().useState("");
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { data: products , isLoading: isLoadingProduct  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)([
        "products",
        router.asPath
    ], _actions_Product_action__WEBPACK_IMPORTED_MODULE_14__/* ["default"].getAll */ .Z.getAll);
    const { data: categories , isLoading: isLoadingCategory  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)([
        "categories"
    ], _actions_Category_action__WEBPACK_IMPORTED_MODULE_12__/* ["default"].getAll */ .Z.getAll);
    react__WEBPACK_IMPORTED_MODULE_5___default().useEffect(()=>{
        setCurrentProduct(products || []);
    }, [
        products
    ]);
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_context__WEBPACK_IMPORTED_MODULE_16__/* .AuthContext */ .V);
    const { mutate , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(_actions_Product_action__WEBPACK_IMPORTED_MODULE_14__/* ["default"]["delete"] */ .Z["delete"], {
        onSuccess: (data, variables)=>{
            react_hot_toast__WEBPACK_IMPORTED_MODULE_6__.toast.success("Đ\xe3 chuyển v\xe0o th\xf9ng r\xe1c");
            queryClient.setQueryData([
                "products",
                router.asPath
            ], products?.filter((item)=>item.id !== variables));
        },
        onError: (err)=>{
            console.log(err);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_6__.toast.error("C\xf3 lỗi xảy ra, vui l\xf2ng thử lại");
        }
    });
    const handleDelete = (id)=>{
        sweetalert__WEBPACK_IMPORTED_MODULE_11___default()({
            title: "Bạn c\xf3 chắc chắn muốn x\xf3a?",
            text: "Khi x\xf3a, đối tượng sẽ được chuyển v\xe0o th\xf9ng r\xe1c",
            icon: "warning",
            buttons: [
                "Hủy",
                "X\xf3a"
            ],
            dangerMode: true
        }).then((willDelete)=>{
            if (willDelete) {
                mutate(id);
            }
        });
    };
    const queryClient = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQueryClient)();
    const { mutate: handlePopular , isLoading: loadingPopular  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(_actions_Popular_action__WEBPACK_IMPORTED_MODULE_13__/* ["default"].popular */ .Z.popular, {
        onSuccess: (data, variables)=>{
            react_hot_toast__WEBPACK_IMPORTED_MODULE_6__.toast.success("Cập nhật sản phẩm nổi bật th\xe0nh c\xf4ng");
            queryClient.setQueryData([
                "products",
                router.asPath
            ], products?.map((item)=>{
                if (item.id === variables) {
                    return {
                        ...item,
                        popular: data == 1 ? null : data
                    };
                }
                return item;
            }));
        },
        onError: (err)=>{
            console.log(err);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_6__.toast.error("C\xf3 lỗi xảy ra, vui l\xf2ng thử lại");
        }
    });
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        if (search.trim().length === 0) {
            setCurrentProduct(products || []);
        }
    }, [
        search
    ]);
    const handleSearch = (e)=>{
        e.preventDefault();
        if (search.trim() != "") {
            setCurrentProduct(currentProduct.filter((item)=>item.name.toLowerCase().indexOf(search.toLowerCase()) != -1 || item.category.name.toLowerCase().indexOf(search.toLowerCase()) != -1 || item.user.email.toLowerCase().indexOf(search.toLowerCase()) != -1));
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-5 grid",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-white bg-primary px-4 py-2 inline rounded-lg",
                                children: "Quản l\xfd sản phẩm"
                            }),
                            user?.detailActions.includes("product:add") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: "/admin/product/add",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center px-2 py-2 rounded-lg bg-green-500 hover:bg-green-700",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_7__.AiFillPlusCircle, {
                                            fontSize: 24,
                                            className: "text-white"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: " text-white ml-2",
                                            children: "Th\xeam sản phẩm"
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SearchAdmin__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                        handleSearch: handleSearch,
                        onChange: (e)=>setSearch(e.target.value),
                        value: search
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mt-4 bg-white rounded-3xl p-4 max-h-[450px] overflow-scroll shadow-master",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "relative",
                            children: !isLoadingProduct || !isLoadingCategory ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                className: "table-auto w-full text-sm text-left text-gray-500 dark:text-gray-400",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                        className: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "H\xecnh ảnh"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "T\xean sản phẩm"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "Danh mục"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "Biến thể"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "Ng\xe0y cập nhật"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "Người đăng"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "Nổi bật"
                                                }),
                                                (user?.detailActions.includes("product:update") || user?.detailActions.includes("product:delete")) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "H\xe0nh động"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                        children: currentProduct?.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                className: "bg-white border-b dark:bg-gray-800 dark:border-gray-700",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        scope: "row",
                                                        className: "py-4 px-6 font-medium text-gray-900 whitespace-nowrap dark:text-white",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_10__.LazyLoadImage, {
                                                            src: (0,_utils__WEBPACK_IMPORTED_MODULE_15__/* .getImageServer */ .KT)(item.thumbnail),
                                                            alt: "123",
                                                            width: 50,
                                                            height: 50
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-4 px-6 break-words max-w-[200px]",
                                                        children: item.name
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-4 px-6 break-words max-w-[200px]",
                                                        children: item.category.name
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-4 px-6",
                                                        children: item.skus.length
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-4 px-6",
                                                        children: dayjs__WEBPACK_IMPORTED_MODULE_2___default()(item.createdAt).format("DD/MM/YYYY")
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-4 px-6 break-words max-w-[300px]",
                                                        children: item.user.email
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-4 px-4",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                            className: "relative inline-flex items-center cursor-pointer",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    type: "checkbox",
                                                                    checked: item.popular !== null,
                                                                    onChange: ()=>handlePopular(item.id),
                                                                    className: "sr-only peer",
                                                                    disabled: loadingPopular
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    (user?.detailActions.includes("product:update") || user?.detailActions.includes("product:delete")) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-4 px-6",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "flex space-x-2",
                                                            children: [
                                                                user?.detailActions.includes("product:update") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    onClick: ()=>{
                                                                        setCurrent(item);
                                                                        setOpenModal(true);
                                                                    },
                                                                    className: "bg-primary flex items-center justify-center text-white p-1 rounded-md hover:bg-primaryHover cursor-pointer",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ci__WEBPACK_IMPORTED_MODULE_8__.CiEdit, {
                                                                        fontSize: 24
                                                                    })
                                                                }),
                                                                user?.detailActions.includes("product:delete") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    onClick: ()=>handleDelete(item.id),
                                                                    className: " bg-red-500 flex items-center justify-center text-white p-1 rounded-md hover:bg-red-700 cursor-pointer",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_9__.RiDeleteBin6Line, {
                                                                        fontSize: 24
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }, item.id))
                                    })
                                ]
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex items-center justify-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LoadingSpinner__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                    isFullScreen: false
                                })
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalUpdateProduct__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                current: current,
                handleClose: ()=>setOpenModal(false),
                open: openModal,
                categories: categories || []
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductAdmin);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9684:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9752);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6201);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8625);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_ci__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9252);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var sweetalert__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4701);
/* harmony import */ var sweetalert__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(sweetalert__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _actions_Sku_action__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3553);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9361);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(506);
/* harmony import */ var _LoadingSpinner__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3595);
/* harmony import */ var _SearchAdmin__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2466);
/* harmony import */ var _ModalUpdateSku__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6772);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hot_toast__WEBPACK_IMPORTED_MODULE_4__, _actions_Sku_action__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__, _context__WEBPACK_IMPORTED_MODULE_10__, _ModalUpdateSku__WEBPACK_IMPORTED_MODULE_13__]);
([_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__, react_hot_toast__WEBPACK_IMPORTED_MODULE_4__, _actions_Sku_action__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__, _context__WEBPACK_IMPORTED_MODULE_10__, _ModalUpdateSku__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const SkuAdmin = ()=>{
    const [openModalUpdate, setOpenModalUpdate] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)();
    const [search, setSearch] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const [currentProduct, setCurrentProduct] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { data: skus , isLoading: isLoadingSku  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)([
        "skus",
        router.asPath
    ], _actions_Sku_action__WEBPACK_IMPORTED_MODULE_8__/* ["default"].getAll */ .Z.getAll);
    react__WEBPACK_IMPORTED_MODULE_3___default().useEffect(()=>{
        setCurrentProduct(skus || []);
    }, [
        skus
    ]);
    const queryClient = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useQueryClient)();
    const { mutate , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_1__.useMutation)(_actions_Sku_action__WEBPACK_IMPORTED_MODULE_8__/* ["default"]["delete"] */ .Z["delete"], {
        onSuccess: (data, variable)=>{
            react_hot_toast__WEBPACK_IMPORTED_MODULE_4__.toast.success("Đ\xe3 chuyển v\xe0o th\xf9ng r\xe1c");
            queryClient.setQueryData([
                "skus",
                router.asPath
            ], skus?.map((item)=>item.id !== variable));
        },
        onError: (err)=>{
            console.log(err);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_4__.toast.error("C\xf3 lỗi xảy ra, vui l\xf2ng thử lại");
        }
    });
    const handleDelete = (id)=>{
        sweetalert__WEBPACK_IMPORTED_MODULE_7___default()({
            title: "Bạn c\xf3 chắc chắn muốn x\xf3a?",
            text: "Khi x\xf3a, đối tượng sẽ kh\xf4ng thể kh\xf4i phục",
            icon: "warning",
            buttons: [
                "Hủy",
                "X\xf3a"
            ],
            dangerMode: true
        }).then((willDelete)=>{
            if (willDelete) {
                mutate(id);
            }
        });
    };
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_context__WEBPACK_IMPORTED_MODULE_10__/* .AuthContext */ .V);
    const handleSearch = (e)=>{
        e.preventDefault();
        setCurrentProduct(currentProduct.filter((item)=>item.product.name.toLowerCase().indexOf(search.toLowerCase()) != -1 || item.sku.toLowerCase().indexOf(search.toLowerCase()) != -1));
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (search.trim().length === 0) {
            setCurrentProduct(skus || []);
        }
    }, [
        search
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-5 grid",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex items-center justify-between",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "text-white bg-primary px-4 py-2 inline rounded-lg",
                            children: "Quản l\xfd h\xe0ng h\xf3a"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SearchAdmin__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        handleSearch: handleSearch,
                        onChange: (e)=>setSearch(e.target.value),
                        value: search,
                        placeholder: "T\xecm kiếm theo t\xean, m\xe3 sku..."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mt-4 bg-white rounded-3xl p-4 max-h-[450px] overflow-scroll shadow-master",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "relative",
                            children: !isLoadingSku ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                className: "table-auto w-full text-sm text-left text-gray-500 dark:text-gray-400",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                        className: "text-xs text-gray-700 sticky uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-2 md:py-3 px-3 md:px-6",
                                                    children: "H\xecnh ảnh"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-2 md:py-3 px-3 md:px-6",
                                                    children: "T\xean sản phẩm"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-2 md:py-3 px-3 md:px-6",
                                                    children: "Loại"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-2 md:py-3 px-3 md:px-6",
                                                    children: "Gi\xe1"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-2 md:py-3 px-3 md:px-6",
                                                    children: "% Giảm"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-2 md:py-3 px-3 md:px-6",
                                                    children: "SKU"
                                                }),
                                                (user?.detailActions.includes("product:update") || user?.detailActions.includes("product:delete")) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "H\xe0nh động"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                        children: currentProduct?.map((item)=>{
                                            const groupByAttribute = item.skuvalues.reduce((group, product)=>{
                                                const { attributeId  } = product;
                                                group[attributeId] = group[attributeId] ?? [];
                                                group[attributeId].push(product);
                                                return group;
                                            }, {});
                                            let types = "";
                                            for(const key in groupByAttribute){
                                                types += `${groupByAttribute[key][0].attribute.name}: `;
                                                groupByAttribute[key].forEach((item)=>{
                                                    types += `${item.detailattribute.name} `;
                                                });
                                                types += " ";
                                            }
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                className: "bg-white border-b dark:bg-gray-800 dark:border-gray-700",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        scope: "row",
                                                        className: "py-2 md:py-4 px-3 md:px-6 font-medium text-gray-900 whitespace-nowrap dark:text-white",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_6__.LazyLoadImage, {
                                                            src: (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .getImageServer */ .KT)(item.image),
                                                            alt: "123",
                                                            width: 50,
                                                            height: 50
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-2 md:py-4 px-3 md:px-6 break-words max-w-[300px]",
                                                        children: item.product.name
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-2 md:py-4 px-3 md:px-6 break-words max-w-[300px]",
                                                        children: types.trim().replace("  ", " , ")
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-2 md:py-4 px-3 md:px-6",
                                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatPrices */ .eQ)(item.price)
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                        className: "py-2 md:py-4 px-3 md:px-6",
                                                        children: [
                                                            item.discount,
                                                            "%"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-2 md:py-4 px-3 md:px-6",
                                                        children: item.sku
                                                    }),
                                                    (user?.detailActions.includes("product:update") || user?.detailActions.includes("product:delete")) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-2 md:py-4 px-3 md:px-6",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "flex",
                                                            children: user?.detailActions.includes("product:update") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                onClick: ()=>{
                                                                    setCurrent(item);
                                                                    setOpenModalUpdate(true);
                                                                },
                                                                className: "bg-primary flex items-center justify-center text-white p-1 rounded-md hover:bg-primaryHover cursor-pointer",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ci__WEBPACK_IMPORTED_MODULE_5__.CiEdit, {
                                                                    fontSize: 24
                                                                })
                                                            })
                                                        })
                                                    })
                                                ]
                                            }, item.id);
                                        })
                                    })
                                ]
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex items-center justify-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LoadingSpinner__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                    isFullScreen: false
                                })
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalUpdateSku__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                current: current,
                handleClose: ()=>setOpenModalUpdate(false),
                open: openModalUpdate
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SkuAdmin);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8082:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8625);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_ci__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _ModalAddSpecies__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8339);
/* harmony import */ var _ModalUpdateSpecies__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4844);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9752);
/* harmony import */ var _actions_Species_action__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2701);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6201);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var sweetalert__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4701);
/* harmony import */ var sweetalert__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(sweetalert__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(506);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9252);
/* harmony import */ var react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9361);
/* harmony import */ var _LoadingSpinner__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3595);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_ModalAddSpecies__WEBPACK_IMPORTED_MODULE_5__, _ModalUpdateSpecies__WEBPACK_IMPORTED_MODULE_6__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_7__, _actions_Species_action__WEBPACK_IMPORTED_MODULE_8__, react_hot_toast__WEBPACK_IMPORTED_MODULE_9__, _context__WEBPACK_IMPORTED_MODULE_12__, _utils__WEBPACK_IMPORTED_MODULE_14__]);
([_ModalAddSpecies__WEBPACK_IMPORTED_MODULE_5__, _ModalUpdateSpecies__WEBPACK_IMPORTED_MODULE_6__, _tanstack_react_query__WEBPACK_IMPORTED_MODULE_7__, _actions_Species_action__WEBPACK_IMPORTED_MODULE_8__, react_hot_toast__WEBPACK_IMPORTED_MODULE_9__, _context__WEBPACK_IMPORTED_MODULE_12__, _utils__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















const SpeciesAdmin = ()=>{
    const [openModalAdd, setOpenModalAdd] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const [openModalUpdate, setOpenModalUpdate] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const queryClient = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_7__.useQueryClient)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    const { data: species , isLoading: isLoadingSpecies  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_7__.useQuery)([
        "species",
        router.asPath
    ], ()=>_actions_Species_action__WEBPACK_IMPORTED_MODULE_8__/* ["default"].getAll */ .Z.getAll(0));
    const { mutate , isLoading  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_7__.useMutation)(_actions_Species_action__WEBPACK_IMPORTED_MODULE_8__/* ["default"]["delete"] */ .Z["delete"], {
        onSuccess: (data, variable)=>{
            react_hot_toast__WEBPACK_IMPORTED_MODULE_9__.toast.success("Đ\xe3 chuyển v\xe0o th\xf9ng r\xe1c");
            queryClient.setQueryData([
                "species",
                router.asPath
            ], species?.filter((item)=>item.id !== variable));
        },
        onError: (err)=>{
            console.log(err);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_9__.toast.error("C\xf3 lỗi xảy ra, vui l\xf2ng thử lại");
        }
    });
    const handleDelete = (id)=>{
        sweetalert__WEBPACK_IMPORTED_MODULE_11___default()({
            title: "Bạn c\xf3 chắc chắn muốn x\xf3a?",
            text: "Khi x\xf3a, đối tượng sẽ được chuyển v\xe0o th\xf9ng r\xe1c",
            icon: "warning",
            buttons: [
                "Hủy",
                "X\xf3a"
            ],
            dangerMode: true
        }).then((willDelete)=>{
            if (willDelete) {
                mutate(id);
            }
        });
    };
    const { mutate: handleMenu , isLoading: loadingMenu  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_7__.useMutation)(_actions_Species_action__WEBPACK_IMPORTED_MODULE_8__/* ["default"].setMenu */ .Z.setMenu, {
        onSuccess: (data)=>{
            react_hot_toast__WEBPACK_IMPORTED_MODULE_9__.toast.success(data.isMenu ? "Đã chuy\xeản l\xean menu" : "Đ\xe3 x\xf3a khỏi menu");
            queryClient.setQueryData([
                "species",
                router.asPath
            ], species?.map((item)=>{
                if (item?.id === data?.id) {
                    return data;
                }
                return item;
            }));
        },
        onError: (err)=>{
            console.log(err);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_9__.toast.error("C\xf3 lỗi xảy ra, vui l\xf2ng thử lại");
        }
    });
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_context__WEBPACK_IMPORTED_MODULE_12__/* .AuthContext */ .V);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-5 grid",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-white bg-primary px-4 py-2 inline rounded-lg",
                                children: "Quản l\xfd chủng loại"
                            }),
                            user?.detailActions.includes("species:add") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>setOpenModalAdd(true),
                                className: "px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-700",
                                children: "Th\xeam chủng loại"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mt-4 bg-white rounded-3xl p-4 max-h-[450px] overflow-scroll shadow-master",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "relative",
                            children: !isLoadingSpecies ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                className: "table-auto w-full text-sm text-left text-gray-500 dark:text-gray-400",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                        className: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "H\xecnh ảnh"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "T\xean chủng loại"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "Ng\xe0y tạo"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "Ng\xe0y cập nhật"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "Menu"
                                                }),
                                                (user?.detailActions.includes("species:update") || user?.detailActions.includes("species:delete")) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    scope: "col",
                                                    className: "py-3 px-6",
                                                    children: "H\xe0nh động"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                        children: species?.map((item)=>{
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                className: "bg-white border-b dark:bg-gray-800 dark:border-gray-700",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        scope: "row",
                                                        className: "py-4 px-6 font-medium text-gray-900 whitespace-nowrap dark:text-white",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_lazy_load_image_component__WEBPACK_IMPORTED_MODULE_13__.LazyLoadImage, {
                                                            width: 60,
                                                            height: 60,
                                                            className: "rounded-md",
                                                            src: (0,_utils__WEBPACK_IMPORTED_MODULE_14__/* .getImageServer */ .KT)(item.thumbnail),
                                                            alt: ""
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-4 px-6 break-words max-w-[300px]",
                                                        children: item.name
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-4 px-6",
                                                        children: dayjs__WEBPACK_IMPORTED_MODULE_1___default()(item.createdAt).format("DD/MM/YYYY")
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-4 px-6",
                                                        children: dayjs__WEBPACK_IMPORTED_MODULE_1___default()(item.updatedAt).format("DD/MM/YYYY")
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-4 px-4",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                            className: "relative inline-flex items-center cursor-pointer",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    type: "checkbox",
                                                                    checked: item.isMenu,
                                                                    onChange: ()=>handleMenu(item.id),
                                                                    className: "sr-only peer",
                                                                    disabled: loadingMenu
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    (user?.detailActions.includes("species:update") || user?.detailActions.includes("species:delete")) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "py-4 px-6",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "flex",
                                                            children: [
                                                                user?.detailActions.includes("species:update") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    onClick: ()=>{
                                                                        setCurrent(item);
                                                                        setOpenModalUpdate(true);
                                                                    },
                                                                    className: "bg-primary flex items-center justify-center text-white p-1 rounded-md hover:bg-primaryHover cursor-pointer",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ci__WEBPACK_IMPORTED_MODULE_3__.CiEdit, {
                                                                        fontSize: 24
                                                                    })
                                                                }),
                                                                user?.detailActions.includes("species:delete") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    onClick: ()=>handleDelete(item.id),
                                                                    className: "ml-2 bg-red-500 flex items-center justify-center text-white p-1 rounded-md hover:bg-red-700 cursor-pointer",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_4__.RiDeleteBin6Line, {
                                                                        fontSize: 24
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }, item.id);
                                        })
                                    })
                                ]
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex items-center justify-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LoadingSpinner__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                    isFullScreen: false
                                })
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalAddSpecies__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                handleClose: ()=>setOpenModalAdd(false),
                open: openModalAdd
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalUpdateSpecies__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                current: current,
                handleClose: ()=>setOpenModalUpdate(false),
                open: openModalUpdate
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SpeciesAdmin);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4517:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_admin_products_PCategoryAdmin__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1713);
/* harmony import */ var _components_admin_products_ProductAdmin__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1165);
/* harmony import */ var _components_admin_products_SkuAdmin__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9684);
/* harmony import */ var _components_admin_products_SpeciesAdmin__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8082);
/* harmony import */ var _components_context__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(506);
/* harmony import */ var _components_layouts_AdminLayout__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9408);
/* harmony import */ var _components_Meta__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4154);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_admin_products_PCategoryAdmin__WEBPACK_IMPORTED_MODULE_3__, _components_admin_products_ProductAdmin__WEBPACK_IMPORTED_MODULE_4__, _components_admin_products_SkuAdmin__WEBPACK_IMPORTED_MODULE_5__, _components_admin_products_SpeciesAdmin__WEBPACK_IMPORTED_MODULE_6__, _components_context__WEBPACK_IMPORTED_MODULE_7__, _components_layouts_AdminLayout__WEBPACK_IMPORTED_MODULE_8__]);
([_components_admin_products_PCategoryAdmin__WEBPACK_IMPORTED_MODULE_3__, _components_admin_products_ProductAdmin__WEBPACK_IMPORTED_MODULE_4__, _components_admin_products_SkuAdmin__WEBPACK_IMPORTED_MODULE_5__, _components_admin_products_SpeciesAdmin__WEBPACK_IMPORTED_MODULE_6__, _components_context__WEBPACK_IMPORTED_MODULE_7__, _components_layouts_AdminLayout__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const ProductAdminManager = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_components_context__WEBPACK_IMPORTED_MODULE_7__/* .AuthContext */ .V);
    const { tab =0  } = router.query;
    const dataTab = [
        {
            id: 0,
            title: "Sản phẩm",
            hide: !user?.detailActions.includes("product:view")
        },
        {
            id: 1,
            title: "H\xe0ng h\xf3a",
            hide: !user?.detailActions.includes("product:view")
        },
        {
            id: 2,
            title: "Chủng loại",
            hide: !user?.detailActions.includes("species:view")
        },
        {
            id: 3,
            title: "Thể loại",
            hide: !user?.detailActions.includes("category:view")
        }
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Meta__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                image: "/images/logo.jpg",
                title: "Sản phẩm | Admin",
                description: ""
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layouts_AdminLayout__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-5",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                            className: "flex flex-wrap text-sm font-medium text-center text-gray-500 border-b border-gray-200 dark:border-gray-700 dark:text-gray-400",
                            children: [
                                dataTab.map((item, index)=>!item.hide && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        onClick: ()=>router.push(`/admin/product?tab=${index}`),
                                        className: "mr-2 cursor-pointer",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: `inline-block p-4 rounded-t-lg  ${item.id === +tab ? "text-primary bg-gray-100" : "hover:bg-gray-100 hover:text-primary"}`,
                                            children: item.title
                                        })
                                    }, item.id))
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                +tab === 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_admin_products_ProductAdmin__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                                +tab === 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_admin_products_SkuAdmin__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                                +tab === 2 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_admin_products_SpeciesAdmin__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                +tab === 3 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_admin_products_PCategoryAdmin__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductAdminManager);
const getServerSideProps = async ({ req  })=>{
    // const data = await Promise.all([
    //   ProductAction.getAll(),
    //   CategoryAction.getAll(),
    //   SpeciesAction.getAll(),
    //   SkuAction.getAll(),
    // ]);
    // const tab = query.tab as string;
    // return {
    //   props: {
    //     products: data[0],
    //     categories: data[1],
    //     species: data[2],
    //     skus: data[3],
    //     tab: tab || 0,
    //   },
    // };
    const detailActions = JSON.parse(req.cookies["detailActions"] || "[]");
    if (detailActions.includes("product:view") || detailActions.includes("species:view") || detailActions.includes("category:view")) {
        return {
            props: {}
        };
    }
    return {
        props: {},
        redirect: {
            destination: "/admin"
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8982:
/***/ ((module) => {

module.exports = require("cookies-next");

/***/ }),

/***/ 1635:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 7840:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 8625:
/***/ ((module) => {

module.exports = require("react-icons/ci");

/***/ }),

/***/ 178:
/***/ ((module) => {

module.exports = require("react-icons/fc");

/***/ }),

/***/ 8098:
/***/ ((module) => {

module.exports = require("react-icons/ri");

/***/ }),

/***/ 4152:
/***/ ((module) => {

module.exports = require("react-icons/tb");

/***/ }),

/***/ 1740:
/***/ ((module) => {

module.exports = require("react-icons/tfi");

/***/ }),

/***/ 382:
/***/ ((module) => {

module.exports = require("react-icons/vsc");

/***/ }),

/***/ 9252:
/***/ ((module) => {

module.exports = require("react-lazy-load-image-component");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4701:
/***/ ((module) => {

module.exports = require("sweetalert");

/***/ }),

/***/ 9752:
/***/ ((module) => {

module.exports = import("@tanstack/react-query");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 6201:
/***/ ((module) => {

module.exports = import("react-hot-toast");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,676,664,183,154,506,361,231,408,220,595,216,426,320,701,466], () => (__webpack_exec__(4517)));
module.exports = __webpack_exports__;

})();