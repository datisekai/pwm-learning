export interface SliderModel {
    id: number;
    image: string;
    url?: string;
    createdAt: Date;
    updatedAt: Date;
}