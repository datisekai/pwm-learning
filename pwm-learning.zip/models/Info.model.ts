export interface InfoModel {
  id: number;
  title: string;
  content: string;
  image?: string;
  createAt: Date;
  updateAt: Date;
  code: string;
}
